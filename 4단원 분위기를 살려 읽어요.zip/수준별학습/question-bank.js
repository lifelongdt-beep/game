const BLOG_URL = "https://blog.naver.com/bojogaesam-ai-class";
const OPTION_LABELS = ["1", "2", "3", "4", "5"];

const CATEGORY_KEYS = [
  "sleepPoem",
  "finalConsonant",
  "readPractice",
  "oceanArticle",
  "pondPoem",
  "recitation"
];

const CATEGORY_OPTIONS = [
  {
    value: "sleepPoem",
    label: "누가 누가 잠자나",
    description: "시의 장면과 읽는 방법을 떠올리며 핵심 내용을 익혀요."
  },
  {
    value: "finalConsonant",
    label: "쌍받침·겹받침",
    description: "받침의 종류와 낱말의 특징을 구별해요."
  },
  {
    value: "readPractice",
    label: "겹받침 읽기",
    description: "겹받침 낱말을 바르게 읽고 문장에 알맞게 넣어요."
  },
  {
    value: "oceanArticle",
    label: "설명글 이해",
    description: "플라스틱 쓰레기 글의 중심 내용을 차례대로 정리해요."
  },
  {
    value: "pondPoem",
    label: "연못 속",
    description: "비유 표현과 시의 분위기를 떠올리며 읽어요."
  },
  {
    value: "recitation",
    label: "낭송과 분위기",
    description: "시의 장면, 마음, 낭송 방법을 함께 생각해요."
  },
  {
    value: "mixed",
    label: "단원 종합",
    description: "4단원에서 배운 문제를 한 번에 섞어 풀어요."
  }
];

const DIFFICULTY_OPTIONS = [
  { value: "low", label: "기본", description: "핵심 문제부터 차근차근 익혀요." },
  { value: "mid", label: "익힘", description: "비슷한 문제를 더 빠르게 풀어요." },
  { value: "high", label: "도전", description: "여러 차시 문제를 넓게 섞어 도전해요." }
];

const TIMER_OPTIONS = [
  { value: 40, label: "40초", description: "짧고 빠르게 풀어요." },
  { value: 60, label: "60초", description: "가장 추천하는 기본 시간이에요." },
  { value: 80, label: "80초", description: "조금 더 여유 있게 풀어요." },
  { value: 100, label: "100초", description: "차분하게 고르고 풀어요." }
];

const PLAYER_COUNT_OPTIONS = [
  { value: 1, label: "1명", description: "혼자 차분하게 연습해요." },
  { value: 2, label: "2명", description: "둘이 함께 도전해요." },
  { value: 3, label: "3명", description: "세 명이 나란히 풀어요." },
  { value: 4, label: "4명", description: "모둠 활동에 잘 맞아요." },
  { value: 5, label: "5명", description: "전자칠판 놀이처럼 즐겨요." }
];

const DIFFICULTY_NAMES = {
  low: "기본",
  mid: "익힘",
  high: "도전"
};

const CATEGORY_NAMES = {
  sleepPoem: "누가 누가 잠자나",
  finalConsonant: "쌍받침·겹받침",
  readPractice: "겹받침 읽기",
  oceanArticle: "설명글 이해",
  pondPoem: "연못 속",
  recitation: "낭송과 분위기",
  mixed: "단원 종합"
};

const PLAYER_COLORS = [
  "var(--player-1)",
  "var(--player-2)",
  "var(--player-3)",
  "var(--player-4)",
  "var(--player-5)"
];

const ANIMAL_PLAYERS = [
  { name: "강아지", avatar: "🐶", voice: "puppy", soundText: "멍멍" },
  { name: "고양이", avatar: "🐱", voice: "kitten", soundText: "야옹" },
  { name: "병아리", avatar: "🐥", voice: "chick", soundText: "삐약" },
  { name: "오리", avatar: "🦆", voice: "duck", soundText: "꽥꽥" },
  { name: "개구리", avatar: "🐸", voice: "frog", soundText: "개굴" }
];

const SHAPE_FILL = {
  triangle: "#ff8f3f",
  square: "#ffd965",
  circle: "#1bb6a5",
  trapezoid: "#7cc7ff"
};

const SCORE_BY_DIFFICULTY = {
  low: 10,
  mid: 14,
  high: 18
};

function createPlayers(count) {
  return Array.from({ length: count }, (_, index) => ({
    id: `player-${index + 1}`,
    name: ANIMAL_PLAYERS[index].name,
    avatar: ANIMAL_PLAYERS[index].avatar,
    voice: ANIMAL_PLAYERS[index].voice,
    soundText: ANIMAL_PLAYERS[index].soundText,
    color: PLAYER_COLORS[index]
  }));
}

const CHARACTER_PHOTO_PATH = "기본 그림";

function clueScene(...lines) {
  return { type: "clues", lines };
}

function passageScene(title, lines, kicker = "지문 읽기") {
  return {
    type: "passage",
    title,
    kicker,
    lines
  };
}

function uniqueChoiceList(answer, options) {
  const seen = new Set();
  return [answer, ...options].filter((choice) => {
    const normalized = String(choice).trim();
    if (!normalized || seen.has(normalized)) {
      return false;
    }
    seen.add(normalized);
    return true;
  });
}

function shuffleChoiceItems(items) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
  }
  return copy;
}

function extractNumericChoice(answerText) {
  const match = String(answerText).trim().match(/^(\d+)([가-힣]*)$/);
  if (!match) {
    return null;
  }

  return {
    value: Number(match[1]),
    suffix: match[2] || ""
  };
}

function buildNumericDistractors(answerText) {
  const parsed = extractNumericChoice(answerText);
  if (!parsed) {
    return [];
  }

  const { value, suffix } = parsed;
  return [1, -1, 2, -2, 10, -10]
    .map((delta) => value + delta)
    .filter((candidate) => candidate >= 0)
    .map((candidate) => `${candidate}${suffix}`);
}

function buildFallbackDistractors(answerText) {
  return [
    `${answerText} 다시`,
    `${answerText} 보기`,
    `${answerText} 장면`,
    `${answerText} 읽기`
  ];
}

function buildFiveChoiceSet(options, answerIndex, extraPool = []) {
  const answerText = options[answerIndex];
  const choicePool = [];
  const seen = new Set();

  function addChoice(text) {
    const normalized = String(text).trim();
    if (!normalized || seen.has(normalized)) {
      return;
    }
    seen.add(normalized);
    choicePool.push(normalized);
  }

  addChoice(answerText);
  options.forEach(addChoice);
  extraPool.forEach(addChoice);
  buildNumericDistractors(answerText).forEach(addChoice);
  buildFallbackDistractors(answerText).forEach(addChoice);

  while (choicePool.length < 5) {
    addChoice(`${answerText} ${choicePool.length + 1}`);
  }

  const shuffled = shuffleChoiceItems(
    choicePool.slice(0, 5).map((text) => ({
      text,
      correct: text === answerText
    }))
  );

  return {
    options: shuffled.map((item) => item.text),
    answer: shuffled.findIndex((item) => item.correct)
  };
}

function isSafeHintLine(line) {
  return Boolean(String(line).trim())
    && !/[=<>+\-]/.test(line)
    && !/\d/.test(line)
    && !String(line).includes("정답");
}

function countPromptWordBlocks(prompt) {
  const matches = String(prompt).match(/[가-힣A-Za-z]+/g);
  return matches ? matches.length : 0;
}

function getBasicPromptPriority(prompt, options) {
  const normalizedPrompt = String(prompt).trim();
  if (normalizedPrompt.length <= 16) {
    return 0;
  }

  if (options.some((option) => String(option).length >= 10)) {
    return 1;
  }

  return 2;
}

function getQuestionDifficultyScore(prompt, options) {
  const normalizedPrompt = String(prompt).trim();
  let score = 0;

  score += Math.min(4, countPromptWordBlocks(normalizedPrompt));

  if (normalizedPrompt.length >= 20) {
    score += 1;
  }

  if (normalizedPrompt.length >= 35) {
    score += 2;
  }

  if (/[‘"“”]/.test(normalizedPrompt)) {
    score += 1;
  }

  if (normalizedPrompt.includes("분위기") || normalizedPrompt.includes("어떻게") || normalizedPrompt.includes("알맞은 태도")) {
    score += 2;
  }

  score += Math.min(
    3,
    options.filter((option) => String(option).trim().length >= 10).length
  );

  return score;
}

function createQuestion(category, id, prompt, options, answerIndex, lines, explanation, extraPool = []) {
  const visibleLines = lines.filter(isSafeHintLine);
  const choiceSet = buildFiveChoiceSet(options, answerIndex, extraPool);

  return {
    category,
    id,
    prompt,
    options: choiceSet.options,
    answer: choiceSet.answer,
    basicPriority: getBasicPromptPriority(prompt, choiceSet.options),
    difficultyScore: getQuestionDifficultyScore(prompt, choiceSet.options),
    scene: visibleLines.length ? clueScene(...visibleLines) : null,
    explanation
  };
}

const QUESTION_TARGET_PER_CATEGORY = 80;
const DIFFICULTY_POOL_TARGETS = {
  low: 20,
  mid: 20,
  high: 16
};

function uniqueById(items) {
  const seen = new Set();
  return items.filter((item) => {
    if (!item || seen.has(item.id)) {
      return false;
    }
    seen.add(item.id);
    return true;
  });
}

function addUniqueQuestions(target, seen, source, limit = source.length) {
  let added = 0;

  for (const item of source) {
    if (!item || seen.has(item.id) || added >= limit) {
      continue;
    }

    seen.add(item.id);
    target.push(item);
    added += 1;
  }
}

function buildDifficultyPool(sortedQuestions, groupedRanks, targetCount) {
  const picked = [];
  const seen = new Set();

  groupedRanks.forEach(({ ranks, limit }) => {
    addUniqueQuestions(
      picked,
      seen,
      sortedQuestions.filter((question) => ranks.includes(question.difficultyRank)),
      limit
    );
  });

  if (picked.length < targetCount) {
    addUniqueQuestions(picked, seen, sortedQuestions, targetCount - picked.length);
  }

  return picked.slice(0, Math.min(targetCount, sortedQuestions.length));
}

function createDifficultyBank(questions) {
  const normalized = uniqueById(questions.slice(0, QUESTION_TARGET_PER_CATEGORY));
  const rankedAscending = normalized
    .map((question, index) => ({ question, index }))
    .sort((left, right) => (
      left.question.difficultyRank - right.question.difficultyRank
      || left.question.basicPriority - right.question.basicPriority
      || left.question.difficultyScore - right.question.difficultyScore
      || left.index - right.index
    ))
    .map((entry) => entry.question);
  const rankedDescending = normalized
    .map((question, index) => ({ question, index }))
    .sort((left, right) => (
      right.question.difficultyRank - left.question.difficultyRank
      || right.question.difficultyScore - left.question.difficultyScore
      || left.index - right.index
    ))
    .map((entry) => entry.question);
  const rankedAroundMiddle = normalized
    .map((question, index) => ({ question, index }))
    .sort((left, right) => (
      Math.abs(left.question.difficultyRank - 3) - Math.abs(right.question.difficultyRank - 3)
      || left.question.difficultyRank - right.question.difficultyRank
      || left.question.difficultyScore - right.question.difficultyScore
      || left.index - right.index
    ))
    .map((entry) => entry.question);

  return {
    low: buildDifficultyPool(
      rankedAscending,
      [
        { ranks: [1], limit: 12 },
        { ranks: [2], limit: 10 },
        { ranks: [3], limit: 6 }
      ],
      DIFFICULTY_POOL_TARGETS.low
    ),
    mid: buildDifficultyPool(
      rankedAroundMiddle,
      [
        { ranks: [3], limit: 10 },
        { ranks: [2], limit: 8 },
        { ranks: [4], limit: 8 },
        { ranks: [1], limit: 4 },
        { ranks: [5], limit: 4 }
      ],
      DIFFICULTY_POOL_TARGETS.mid
    ),
    high: buildDifficultyPool(
      rankedDescending,
      [
        { ranks: [5], limit: 8 },
        { ranks: [4], limit: 10 },
        { ranks: [3], limit: 8 },
        { ranks: [2], limit: 4 }
      ],
      DIFFICULTY_POOL_TARGETS.high
    )
  };
}

const CATEGORY_THEME_MAP = {
  sleepPoem: "누가 누가 잠자나",
  finalConsonant: "받침을 살펴봐",
  readPractice: "겹받침 낱말 읽기",
  oceanArticle: "바다를 지켜요",
  pondPoem: "연못 속",
  recitation: "오늘을 낭송해요"
};

const SLEEP_POEM_PASSAGE = passageScene("누가 누가 잠자나", [
  "넓고 넓은 밤하늘엔 누가 누가 잠자나.",
  "하늘 나라 아기별이 깜박깜박 잠자지.",
  "깊고 깊은 숲속에선 누가 누가 잠자나.",
  "산새 들새 모여 앉아 꼬박꼬박 잠자지.",
  "포근포근 엄마 품엔 누가 누가 잠자나.",
  "우리 아기 예쁜 아기 새근새근 잠자지."
]);

const READ_PRACTICE_DIARY_PASSAGE = passageScene("이어달리기와 그림책 놀이", [
  "오늘 학교에서 많은 일이 있었다.",
  "선생님과 함께 넓은 운동장에 가서 달리기를 했다.",
  "친구들과 이어서 하는 달리기이기 때문에 나는 내 몫을 잘하겠다고 다짐했다.",
  "모두들 최선을 다해서 달렸다.",
  "선생님께서 “열심히 하는 모습이 값진 일이다.”라고 하셨다.",
  "교실에 들어와서 의자에 앉았다.",
  "선생님께서 그림책을 읽어 주시고 몸으로 나타내기를 했다."
]);

const OCEAN_ARTICLE_PASSAGE = passageScene("바다에 쓰레기가 모여 있다고?", [
  "바다에 있는 플라스틱 쓰레기 더미는 바다에서 물고기를 잡거나 기를 때 사용한 그물, 부표 따위가 모여서 만들어져요.",
  "이 더미는 우리가 함부로 버리는 페트병, 물휴지, 과자 봉지 따위가 강을 통해 바다로 흘러들어 가서 점점 더 커진다고 해요.",
  "플라스틱 쓰레기가 바다에 모이는 것을 막으려고 많은 사람이 노력하고 있어요.",
  "환경 단체들은 해안가에 있는 플라스틱 쓰레기를 줍거나 바다에 떠다니는 쓰레기를 모아 없애기도 해요.",
  "우리도 함께 노력할 수 있어요.",
  "평소에 일회용 플라스틱을 덜 사용하거나 플라스틱을 재활용할 수 있도록 분류해서 버려요."
]);

const POND_POEM_PASSAGE = passageScene("연못 속", [
  "연못 속으로 사람이 거꾸로 걸어간다.",
  "소가 거꾸로 따라간다.",
  "나무가 거꾸로 쳐다본다.",
  "연못 속에는 새들이 고기처럼 헤엄쳐 다닌다.",
  "구름이 방석처럼 깔려 있다.",
  "해님이 모닥불처럼 피어오른다."
]);

const TODAY_PASSAGE = passageScene("오늘 낭송하기", [
  "오늘은 좋은 일이 많을 거야.",
  "안녕!",
  "야호!",
  "시의 장면과 마음을 떠올리며 읽어 봅시다.",
  "시 낭송 방법을 정하고 분위기에 어울리는 목소리로 읽어 봅시다."
]);

const RECITATION_ACTIVITY_PASSAGE = passageScene("낭송 활동", [
  "손뼉 치기, 역할 나누기, 몸짓 하기, 음정 넣기 같은 낭송 방법을 떠올려 봅시다.",
  "시집에서 마음에 드는 시를 정해 옮겨 쓰고 친구들 앞에서 낭송해 봅시다.",
  "친구의 시 낭송을 들을 때는 시 속 인물의 마음과 시의 분위기를 상상하며 들어 봅시다.",
  "시의 재미를 느끼며 새로운 책도 스스로 찾아 읽어 봅시다."
]);

const WIND_PASSAGE = passageScene("바람은 착하지", [
  "바람이 신문지 한 장을 끌고 골목으로 나갔어요.",
  "바람은 신문지로 목도리를 만들었어요.",
  "그리고 민들레꽃에게 “힘내렴!” 하고 말하는 마음을 전했어요.",
  "시를 읽으며 따뜻하고 다정한 바람의 마음을 떠올려 봅시다."
]);

function resolvePassageSceneForQuestion(category, questionId) {
  if (category === "sleepPoem") {
    return SLEEP_POEM_PASSAGE;
  }

  if (category === "oceanArticle") {
    return OCEAN_ARTICLE_PASSAGE;
  }

  if (category === "pondPoem") {
    return POND_POEM_PASSAGE;
  }

  if (category === "readPractice") {
    if (/(base-(4|5)|extra-(2|3)|diary-)/.test(questionId)) {
      return READ_PRACTICE_DIARY_PASSAGE;
    }

    return null;
  }

  if (category === "recitation") {
    if (questionId.includes("wind")) {
      return WIND_PASSAGE;
    }

    if (questionId.includes("recite") || questionId.includes("listen")) {
      return RECITATION_ACTIVITY_PASSAGE;
    }

    return TODAY_PASSAGE;
  }

  return null;
}

const importedStages = Array.isArray(window.importedStages) ? window.importedStages : [];
const stageByTheme = new Map(importedStages.map((stage) => [stage.theme, stage]));

function makeSpec(id, prompt, answer, options, lines, explanation, rank = null) {
  return {
    id,
    prompt,
    options: uniqueChoiceList(answer, options),
    answer: 0,
    lines,
    explanation,
    rank
  };
}

function buildStageCardSpecs(category) {
  const stage = stageByTheme.get(CATEGORY_THEME_MAP[category]);
  if (!stage || !Array.isArray(stage.cards)) {
    return [];
  }

  return stage.cards.map((card, index) => makeSpec(
    `${category}-base-${index + 1}`,
    card.prompt,
    card.answer,
    card.options,
    [stage.theme, stage.focus, card.line],
    `${card.line}. ${stage.focus}를 떠올리며 읽어 보면 정답이 더 또렷하게 보여요.`
  ));
}

const EXTRA_SPECS = {
  sleepPoem: [
    makeSpec(
      "sleepPoem-extra-1",
      "아기별이 잠자는 모습을 나타내는 말은?",
      "깜박깜박",
      ["꼬박꼬박", "새근새근"],
      ["하늘 나라 아기별", "깜박깜박 잠자지", "시 속 잠자는 모습"],
      "밤하늘의 아기별은 깜박깜박 잠자지. 누구와 어떤 모습이 이어지는지 시 속에서 찾아보면 좋아요."
    ),
    makeSpec(
      "sleepPoem-extra-2",
      "친구들이 이 시를 읽는 방법으로 알맞은 것은?",
      "손뼉을 치거나 발을 구르며 읽기",
      ["한 사람만 끝까지 조용히 읽기", "문제만 풀듯 빠르게 읽기"],
      ["시를 읽는 방법", "손뼉을 치거나 발을 구르며", "리듬을 살려 읽기"],
      "이 시는 리듬을 살려 읽을 수 있어요. 손뼉을 치거나 발을 구르며 읽으면 느낌이 더 살아나요."
    ),
    makeSpec(
      "sleepPoem-extra-3",
      "이 시에서 느껴지는 분위기로 알맞은 것은?",
      "포근하고 조용해",
      ["시끌벅적하고 바빠", "무섭고 답답해"],
      ["포근포근 엄마 품", "새근새근 잠자지", "잠자는 장면"],
      "밤하늘, 숲속, 엄마 품에서 모두 잠자는 장면이 이어져서 포근하고 조용한 분위기가 느껴져요."
    ),
    makeSpec(
      "sleepPoem-extra-4",
      "시에 나온 잠자는 장면의 차례로 알맞은 것은?",
      "아기별 → 산새와 들새 → 우리 아기",
      ["우리 아기 → 아기별 → 산새와 들새", "산새와 들새 → 우리 아기 → 아기별"],
      ["밤하늘에서는 아기별", "숲속에서는 산새와 들새", "엄마 품에서는 우리 아기"],
      "이 시는 밤하늘, 숲속, 엄마 품 순서로 장면이 이어져요. 누가 어디서 잠자는지 차례대로 떠올리면 돼요."
    )
  ],
  finalConsonant: [
    makeSpec(
      "finalConsonant-extra-1",
      "쌍받침이 있는 낱말은?",
      "있다",
      ["우산", "하늘"],
      ["쌍받침", "ㄲ, ㅆ", "낱말의 받침"],
      "‘있다’의 받침 ㅆ은 쌍받침이에요. 받침에 같은 자음이 두 번 쓰였는지 살펴보면 돼요."
    ),
    makeSpec(
      "finalConsonant-extra-2",
      "겹받침이 있는 낱말은?",
      "앉다",
      ["사랑", "비행기"],
      ["겹받침", "ㄵ, ㄼ", "낱말의 받침"],
      "‘앉다’의 받침 ㄵ은 자음 두 개가 함께 쓰인 겹받침이에요."
    ),
    makeSpec(
      "finalConsonant-extra-3",
      "받침이 없는 낱말은?",
      "비행기",
      ["값", "앉다"],
      ["받침이 없는 낱말", "마지막 글자 소리", "낱말의 특징"],
      "‘비행기’는 마지막 글자 ‘기’에 받침이 없어요. 낱말 끝 글자를 살펴보면 쉽게 찾을 수 있어요."
    ),
    makeSpec(
      "finalConsonant-extra-4",
      "받침 종류가 다른 하나는?",
      "앉다",
      ["낚시", "있다"],
      ["낚시·있다는 쌍받침", "앉다는 겹받침", "받침 종류 비교"],
      "‘낚시’, ‘있다’는 쌍받침이고 ‘앉다’는 겹받침이에요. 같은 종류끼리 묶어 보면 다른 하나가 보여요."
    )
  ],
  readPractice: [
    makeSpec(
      "readPractice-extra-1",
      "‘없다’를 바르게 읽은 것은?",
      "[업따]",
      ["[없다]", "[업다]"],
      ["없다", "겹받침 읽기", "소리 내어 읽기"],
      "‘없다’는 받침 ㅄ이 소리 날 때 [업따]로 읽어요. 실제로 소리 내 보면 더 잘 익어요."
    ),
    makeSpec(
      "readPractice-extra-2",
      "이어달리기 일기에서 알맞은 말은? ‘열심히 하는 모습이 ___ 일이다.’",
      "값진",
      ["갑찐", "맑은"],
      ["일기 완성", "값진 일", "겹받침 낱말"],
      "선생님께서 열심히 하는 모습이 값진 일이라고 하셨어요. 문장 뜻에 어울리는 낱말을 고르면 돼요."
    ),
    makeSpec(
      "readPractice-extra-3",
      "이어달리기 일기에서 알맞은 말은? ‘선생님께서 그림책을 ___ 주시고’",
      "읽어",
      ["일거", "읽고"],
      ["일기 완성", "그림책을 읽어 주시고", "문장 흐름"],
      "문장 전체를 자연스럽게 이어 읽으면 ‘읽어 주시고’가 가장 알맞아요."
    )
  ],
  oceanArticle: [
    makeSpec(
      "oceanArticle-extra-1",
      "바다 쓰레기 더미는 시간이 갈수록 어떻게 될까?",
      "점점 더 커져",
      ["조금씩 사라져", "모두 산으로 가"],
      ["플라스틱 쓰레기 더미", "강을 통해 바다로", "점점 더 커져"],
      "플라스틱 쓰레기가 계속 흘러들어 가서 더미는 점점 더 커진다고 했어요."
    ),
    makeSpec(
      "oceanArticle-extra-2",
      "우리가 함께 노력할 수 있다고 한 까닭은?",
      "실천할 수 있는 방법이 있어서",
      ["우리 힘으로는 아무것도 못 해서", "바다가 스스로 치워서"],
      ["함께 노력", "평소에 실천", "일회용 플라스틱 줄이기"],
      "글에서는 우리가 일회용 플라스틱을 덜 쓰고 분류해 버리는 실천을 할 수 있다고 했어요."
    ),
    makeSpec(
      "oceanArticle-extra-3",
      "플라스틱을 재활용할 수 있도록 어떻게 해야 할까?",
      "분류해서 버려",
      ["한곳에 섞어 버려", "그냥 땅에 묻어"],
      ["재활용", "분류해서 버리기", "실천 방법"],
      "재활용을 하려면 플라스틱을 종류에 맞게 분류해서 버려야 해요."
    ),
    makeSpec(
      "oceanArticle-extra-4",
      "글의 내용이 흘러가는 순서로 알맞은 것은?",
      "플라스틱이 강을 거쳐 바다로 가고, 더미가 커져",
      ["더미가 먼저 없어지고 강으로 흘러가", "바다에서 생긴 쓰레기가 산으로 올라가"],
      ["강을 통해 바다로", "플라스틱 쓰레기 더미", "점점 더 커져"],
      "글에서는 사람들이 버린 플라스틱이 강을 거쳐 바다로 가고, 그 결과 바다의 쓰레기 더미가 점점 커진다고 설명해요."
    )
  ],
  pondPoem: [
    makeSpec(
      "pondPoem-extra-1",
      "나무는 연못 속에서 어떻게 보일까?",
      "거꾸로 쳐다봐",
      ["방석처럼 깔려 있어", "고기처럼 헤엄쳐"],
      ["나무가 거꾸로", "연못 속 장면", "비친 모습"],
      "연못에 비친 나무는 거꾸로 쳐다보는 것처럼 보여요."
    ),
    makeSpec(
      "pondPoem-extra-2",
      "이 시의 분위기로 알맞은 것은?",
      "신기하고 재미있어",
      ["무섭고 음침해", "몹시 시끄러워"],
      ["연못 속", "거꾸로 보이는 장면", "신기한 느낌"],
      "사람과 소와 나무가 거꾸로 보이고 새가 고기처럼 헤엄쳐서 신기하고 재미있는 분위기가 느껴져요."
    ),
    makeSpec(
      "pondPoem-extra-3",
      "거꾸로 보이는 것을 모두 떠올리게 하는 장면은?",
      "사람과 소와 나무",
      ["구름과 방석", "해님과 모닥불"],
      ["거꾸로 걸어간다", "거꾸로 따라간다", "거꾸로 쳐다본다"],
      "시에서는 사람, 소, 나무가 차례대로 거꾸로 보인다고 했어요. 장면을 순서대로 떠올리면 찾을 수 있어요."
    ),
    makeSpec(
      "pondPoem-extra-4",
      "연못 속 장면이 신기하게 느껴지는 까닭은?",
      "실제 모습과 거꾸로 비쳐서",
      ["모두 잠들어 있어서", "시끄러운 소리가 나서"],
      ["거꾸로 걸어가", "거꾸로 따라가", "거꾸로 쳐다봐"],
      "사람, 소, 나무가 실제와 반대로 거꾸로 비쳐 보여서 연못 속 장면이 더 신기하게 느껴져요."
    )
  ],
  recitation: [
    makeSpec(
      "recitation-extra-1",
      "배운 내용을 실천할 때 활용할 수 있는 낭송 방법은?",
      "손뼉 치기, 역할 나누기, 몸짓 넣기",
      ["아무 느낌 없이 빠르게 읽기", "시를 보지 않고 아무 말 하기"],
      ["낭송 방법", "손뼉 치기", "몸짓 표현"],
      "지도안에서는 손뼉 치기, 역할 나누기, 몸짓 넣기처럼 여러 낭송 방법을 떠올려 보라고 했어요."
    ),
    makeSpec(
      "recitation-extra-2",
      "친구의 시 낭송을 들으며 파악하면 좋은 것은?",
      "시의 분위기",
      ["친구의 연필 색깔", "책상 배치"],
      ["친구의 시 낭송", "시의 분위기", "마음을 상상하기"],
      "친구의 시 낭송을 들을 때는 시 속 인물의 마음과 시의 분위기를 함께 느끼는 것이 중요해요."
    ),
    makeSpec(
      "recitation-extra-3",
      "시를 바꿔 쓰고 읽는 활동에서 먼저 하면 좋은 것은?",
      "자신의 경험과 관련짓기",
      ["모든 시를 똑같이 외우기", "받침 개수만 세기"],
      ["시 바꿔 쓰기", "자신의 경험", "마음과 장면 연결"],
      "시를 바꿔 쓸 때는 자신의 경험과 관련지어야 마음과 장면이 자연스럽게 살아나요."
    )
  ]
};

const SLEEP_POEM_FACTS = [
  {
    key: "star",
    place: "밤하늘",
    placeFull: "넓고 넓은 밤하늘",
    subject: "하늘 나라 아기별",
    subjectShort: "아기별",
    mode: "깜박깜박",
    action: "깜박깜박 잠자지",
    gesture: "손가락을 반짝이며 조용히 눈을 감는 모습",
    rank: 1
  },
  {
    key: "birds",
    place: "숲속",
    placeFull: "깊고 깊은 숲속",
    subject: "산새와 들새",
    subjectShort: "산새와 들새",
    mode: "꼬박꼬박",
    action: "모여 앉아 꼬박꼬박 잠자지",
    gesture: "새처럼 모여 앉아 가만히 쉬는 모습",
    rank: 1
  },
  {
    key: "baby",
    place: "엄마 품",
    placeFull: "포근포근 엄마 품",
    subject: "우리 아기",
    subjectShort: "우리 아기",
    mode: "새근새근",
    action: "새근새근 잠자지",
    gesture: "몸을 웅크리고 포근하게 자는 모습",
    rank: 1
  }
];

SLEEP_POEM_FACTS.forEach((item, index, all) => {
  const otherSubjects = all.filter((entry) => entry.key !== item.key).map((entry) => entry.subject);
  const otherShortSubjects = all.filter((entry) => entry.key !== item.key).map((entry) => entry.subjectShort);
  const otherPlaces = all.filter((entry) => entry.key !== item.key).map((entry) => entry.place);
  const otherPlacePhrases = all.filter((entry) => entry.key !== item.key).map((entry) => entry.placeFull);
  const otherModes = all.filter((entry) => entry.key !== item.key).map((entry) => entry.mode);

  EXTRA_SPECS.sleepPoem.push(
    makeSpec(
      `sleepPoem-hwp-place-${index + 1}`,
      `${item.placeFull}에서 잠자는 것은?`,
      item.subject,
      otherSubjects,
      [item.placeFull, item.action],
      `${item.placeFull}에서는 ${item.subject}이 ${item.action}. 시 속 장소와 대상을 함께 떠올리면 쉬워요.`,
      item.rank
    ),
    makeSpec(
      `sleepPoem-hwp-subject-${index + 1}`,
      `${item.subjectShort}는 어디에서 잠자나?`,
      item.place,
      otherPlaces,
      [item.subject, item.action],
      `${item.subjectShort}가 잠자는 곳은 ${item.place}예요. 누가 어디에서 잠자는지 짝을 맞춰 보면 또렷해져요.`,
      item.rank
    ),
    makeSpec(
      `sleepPoem-hwp-mode-${index + 1}`,
      `${item.subjectShort}가 잠자는 모습을 나타낸 말은?`,
      item.mode,
      otherModes,
      [item.subject, item.action],
      `${item.subjectShort}는 ${item.mode} 잠자요. 잠자는 대상과 모습을 함께 묶어서 읽어 보세요.`,
      2
    ),
    makeSpec(
      `sleepPoem-hwp-modewho-${index + 1}`,
      `‘${item.mode}’ 잠자는 것은 누구인가?`,
      item.subjectShort,
      otherShortSubjects,
      [item.placeFull, item.action],
      `시에서는 ${item.subjectShort}가 ${item.mode} 잠자는 모습으로 그려져요.`,
      2
    ),
    makeSpec(
      `sleepPoem-hwp-placephrase-${index + 1}`,
      `${item.place}을 알맞게 나타낸 말은?`,
      item.placeFull,
      otherPlacePhrases,
      [item.placeFull, item.subject],
      `${item.place}은 시에서 ‘${item.placeFull}’처럼 꾸며져 있어요.`,
      2
    ),
    makeSpec(
      `sleepPoem-hwp-gesture-${index + 1}`,
      `${item.subjectShort}가 잠자는 장면을 몸짓으로 표현할 때 알맞은 것은?`,
      item.gesture,
      all.filter((entry) => entry.key !== item.key).map((entry) => entry.gesture),
      [item.subject, item.action],
      `${item.subjectShort}가 잠자는 장면을 떠올리며 몸짓으로 나타내면 시의 장면이 더 잘 살아나요.`,
      4
    )
  );
});

EXTRA_SPECS.sleepPoem.push(
  makeSpec(
    "sleepPoem-hwp-order-1",
    "시에서 가장 먼저 나오는 장소는?",
    "밤하늘",
    ["숲속", "엄마 품"],
    ["누가 누가 잠자나", "밤하늘 → 숲속 → 엄마 품"],
    "이 시는 밤하늘에서 시작해서 숲속, 엄마 품으로 이어져요.",
    2
  ),
  makeSpec(
    "sleepPoem-hwp-order-2",
    "시에서 숲속 다음에 나오는 장소는?",
    "엄마 품",
    ["밤하늘", "연못 속"],
    ["밤하늘", "숲속", "엄마 품"],
    "시의 장면은 밤하늘, 숲속, 엄마 품 차례예요.",
    3
  ),
  makeSpec(
    "sleepPoem-hwp-order-3",
    "잠자는 대상의 차례로 알맞은 것은?",
    "아기별 → 산새와 들새 → 우리 아기",
    ["우리 아기 → 아기별 → 산새와 들새", "산새와 들새 → 우리 아기 → 아기별"],
    ["밤하늘", "숲속", "엄마 품"],
    "장면의 흐름에 따라 아기별, 산새와 들새, 우리 아기가 차례로 나와요.",
    4
  ),
  makeSpec(
    "sleepPoem-hwp-method-1",
    "친구들과 이 시를 읽는 방법으로 알맞은 것은?",
    "두 행씩 주고받으며 읽기",
    ["아무 느낌 없이 한 사람만 읽기", "문제집 읽듯 아주 빨리 읽기"],
    ["시 읽기 방법", "리듬을 살려 읽기"],
    "짧은 행이 이어지는 시라서 두 행씩 주고받으며 읽으면 느낌이 잘 살아나요.",
    3
  ),
  makeSpec(
    "sleepPoem-hwp-method-2",
    "이 시의 리듬을 살려 읽는 방법으로 알맞은 것은?",
    "손뼉을 치거나 발을 구르며 읽기",
    ["처음부터 끝까지 아주 작은 목소리로만 읽기", "뜻을 생각하지 않고 빠르게 넘기기"],
    ["시 읽기 방법", "손뼉", "발 구르기"],
    "반복되는 말이 많아서 손뼉을 치거나 발을 구르며 읽으면 시의 리듬이 느껴져요.",
    4
  ),
  makeSpec(
    "sleepPoem-hwp-feeling-1",
    "이 시를 읽고 떠오르는 느낌으로 알맞은 것은?",
    "편안하고 따뜻한 느낌",
    ["시끄럽고 정신없는 느낌", "깜짝 놀라고 무서운 느낌"],
    ["포근포근 엄마 품", "새근새근 잠자지"],
    "밤하늘, 숲속, 엄마 품에서 모두 잠자는 장면이 이어져 편안하고 따뜻한 느낌이 나요.",
    5
  )
);

const FINAL_CONSONANT_GROUPS = [
  {
    key: "ssang",
    label: "쌍받침을 사용한 낱말",
    explanation: "같은 자음이 두 번 쓰인 받침을 쓴 낱말이에요.",
    rank: 1,
    words: ["낚시", "있다"]
  },
  {
    key: "gyeop",
    label: "겹받침을 사용한 낱말",
    explanation: "서로 다른 자음 두 개가 함께 쓰인 받침을 쓴 낱말이에요.",
    rank: 2,
    words: ["앉다", "넓다", "많다", "여덟", "없다", "값"]
  },
  {
    key: "single",
    label: "하나의 자음자를 받침으로 쓴 낱말",
    explanation: "받침에 자음자 한 개만 들어 있는 낱말이에요.",
    rank: 2,
    words: ["학교", "강물", "사랑", "걷다", "꽃", "하늘", "우산"]
  },
  {
    key: "none",
    label: "받침이 없는 낱말",
    explanation: "마지막 글자에 받침이 없는 낱말이에요.",
    rank: 1,
    words: ["나라", "오리", "비행기"]
  }
];

const FINAL_CONSONANT_LABELS = FINAL_CONSONANT_GROUPS.map((group) => group.label);

FINAL_CONSONANT_GROUPS.forEach((group) => {
  group.words.forEach((word, index) => {
    EXTRA_SPECS.finalConsonant.push(
      makeSpec(
        `finalConsonant-hwp-classify-${group.key}-${index + 1}`,
        `‘${word}’의 받침 특징으로 알맞은 것은?`,
        group.label,
        FINAL_CONSONANT_LABELS.filter((label) => label !== group.label),
        [word, group.label],
        `‘${word}’는 ${group.explanation}`,
        group.rank
      )
    );
  });
});

EXTRA_SPECS.finalConsonant.push(
  makeSpec(
    "finalConsonant-hwp-compare-1",
    "‘많다’, ‘여덟’과 같은 종류의 받침이 있는 낱말은?",
    "없다",
    ["학교", "오리"],
    ["많다", "여덟", "겹받침"],
    "‘많다’, ‘여덟’, ‘없다’는 모두 겹받침이 들어 있는 낱말이에요.",
    3
  ),
  makeSpec(
    "finalConsonant-hwp-compare-2",
    "‘학교’, ‘강물’, ‘사랑’의 공통점은?",
    "하나의 자음자를 받침으로 쓴다",
    ["쌍받침을 쓴다", "받침이 없다"],
    ["학교", "강물", "사랑"],
    "세 낱말 모두 받침에 자음자 한 개만 들어 있어요.",
    3
  ),
  makeSpec(
    "finalConsonant-hwp-compare-3",
    "받침에 자음자 두 개를 쓴 낱말은?",
    "값",
    ["꽃", "우산"],
    ["값", "받침 개수"],
    "‘값’은 받침에 자음자 두 개를 쓴 겹받침 낱말이에요.",
    3
  ),
  makeSpec(
    "finalConsonant-hwp-compare-4",
    "받침이 없는 낱말끼리 바르게 묶은 것은?",
    "나라, 오리",
    ["낚시, 있다", "학교, 사랑"],
    ["나라", "오리", "받침 없음"],
    "‘나라’와 ‘오리’는 마지막 글자에 받침이 없어요.",
    2
  ),
  makeSpec(
    "finalConsonant-hwp-compare-5",
    "쌍받침 낱말끼리 바르게 묶은 것은?",
    "낚시, 있다",
    ["앉다, 넓다", "하늘, 우산"],
    ["낚시", "있다", "쌍받침"],
    "‘낚시’의 ㄲ, ‘있다’의 ㅆ은 쌍받침이에요.",
    2
  ),
  makeSpec(
    "finalConsonant-hwp-compare-6",
    "겹받침 낱말끼리 바르게 묶은 것은?",
    "앉다, 넓다",
    ["낚시, 있다", "학교, 강물"],
    ["앉다", "넓다", "겹받침"],
    "‘앉다’와 ‘넓다’는 자음 두 개를 받침으로 써서 겹받침 낱말이에요.",
    2
  ),
  makeSpec(
    "finalConsonant-hwp-compare-7",
    "받침에 쓰인 자음자 개수가 다른 하나는?",
    "값",
    ["꽃", "걷다"],
    ["꽃", "걷다", "값"],
    "‘꽃’과 ‘걷다’는 자음자 한 개를 받침으로 쓰고, ‘값’은 두 개를 써요.",
    4
  ),
  makeSpec(
    "finalConsonant-hwp-compare-8",
    "‘비행기’에 대한 설명으로 알맞은 것은?",
    "마지막 글자에 받침이 없다",
    ["쌍받침이 들어 있다", "겹받침이 들어 있다"],
    ["비행기", "받침이 없는 낱말"],
    "‘비행기’의 마지막 글자 ‘기’에는 받침이 없어요.",
    1
  ),
  makeSpec(
    "finalConsonant-hwp-compare-9",
    "‘앉다’에 대한 설명으로 알맞은 것은?",
    "두 개의 자음자를 받침으로 쓴다",
    ["같은 자음이 두 번 쓰인 받침이다", "받침이 없는 낱말이다"],
    ["앉다", "ㄵ", "겹받침"],
    "‘앉다’는 ㄵ을 받침으로 쓰는 겹받침 낱말이에요.",
    3
  ),
  makeSpec(
    "finalConsonant-hwp-compare-10",
    "‘낚시’에 대한 설명으로 알맞은 것은?",
    "같은 자음이 두 번 쓰인 받침이 있다",
    ["받침이 없다", "서로 다른 자음 두 개를 받침으로 쓴다"],
    ["낚시", "ㄲ", "쌍받침"],
    "‘낚시’의 받침 ㄲ은 같은 자음이 두 번 쓰인 쌍받침이에요.",
    2
  )
);

const READ_PRACTICE_WORDS = [
  { word: "많다", pron: "[만타]", wrongs: ["[많다]", "[만다]"], rank: 2 },
  { word: "여덟", pron: "[여덜]", wrongs: ["[여들]", "[여덟]"], rank: 2 },
  { word: "몫", pron: "[목]", wrongs: ["[몯]", "[몫]"], rank: 2 },
  { word: "앉다", pron: "[안따]", wrongs: ["[안자]", "[앉따]"], rank: 2 },
  { word: "없다", pron: "[업따]", wrongs: ["[업다]", "[없다]"], rank: 3 },
  { word: "있다", pron: "[읻따]", wrongs: ["[잇따]", "[있다]"], rank: 3 },
  { word: "맑다", pron: "[막따]", wrongs: ["[말따]", "[막다]"], rank: 3 },
  { word: "값", pron: "[갑]", wrongs: ["[갓]", "[값]"], rank: 3 },
  { word: "흙", pron: "[흑]", wrongs: ["[흘]", "[흙]"], rank: 3 },
  { word: "품삯", pron: "[품싹]", wrongs: ["[품삭]", "[품삯]"], rank: 4 },
  { word: "괜찮다", pron: "[괜찬타]", wrongs: ["[괜찮다]", "[괜찬다]"], rank: 4 },
  { word: "가엾다", pron: "[가엽따]", wrongs: ["[가엾다]", "[가엽다]"], rank: 4 },
  { word: "귀찮다", pron: "[귀찬타]", wrongs: ["[귀찮다]", "[귀찬다]"], rank: 4 },
  { word: "학교", pron: "[학꾜]", wrongs: ["[학교]", "[하꾜]"], rank: 3 },
  { word: "낚시", pron: "[낙씨]", wrongs: ["[낚시]", "[낙시]"], rank: 3 }
];

READ_PRACTICE_WORDS.forEach((item, index, all) => {
  EXTRA_SPECS.readPractice.push(
    makeSpec(
      `readPractice-hwp-pron-${index + 1}`,
      `‘${item.word}’를 바르게 읽은 것은?`,
      item.pron,
      item.wrongs,
      [item.word, item.pron],
      `‘${item.word}’는 ${item.pron}로 읽어요. 입으로 소리 내어 읽어 보면 더 잘 익어요.`,
      item.rank
    )
  );

  if (index < 10) {
    EXTRA_SPECS.readPractice.push(
      makeSpec(
        `readPractice-hwp-reverse-${index + 1}`,
        `${item.pron}로 읽는 낱말은?`,
        item.word,
        all.filter((entry) => entry.word !== item.word).slice(index % 5, (index % 5) + 2).map((entry) => entry.word),
        [item.word, item.pron],
        `${item.pron}로 읽는 낱말은 ‘${item.word}’예요. 소리와 글자를 함께 떠올리면 좋아요.`,
        Math.min(5, item.rank + 1)
      )
    );
  }
});

EXTRA_SPECS.readPractice.push(
  makeSpec(
    "readPractice-hwp-diary-1",
    "이어달리기 일기에서 알맞은 말은? ‘오늘 학교에서 ___ 일이 있었다.’",
    "많은",
    ["마는", "맑은"],
    ["이어달리기와 그림책 놀이", "많은 일이 있었다"],
    "문장 뜻에 맞고 글에서도 쓰인 말은 ‘많은’이에요.",
    2
  ),
  makeSpec(
    "readPractice-hwp-diary-2",
    "이어달리기 일기에서 알맞은 말은? ‘선생님과 함께 ___ 운동장에 가서 달리기를 했다.’",
    "넓은",
    ["널븐", "낡은"],
    ["운동장", "넓은 운동장"],
    "운동장의 모습을 나타내는 알맞은 말은 ‘넓은’이에요.",
    2
  ),
  makeSpec(
    "readPractice-hwp-diary-3",
    "이어달리기 일기에서 알맞은 말은? ‘나는 내 ___ 잘하겠다고 다짐했다.’",
    "몫을",
    ["목슬", "값을"],
    ["이어달리기", "내 몫을"],
    "이어달리기에서는 각자 맡은 몫을 잘해야 하므로 ‘몫을’이 알맞아요.",
    3
  ),
  makeSpec(
    "readPractice-hwp-diary-4",
    "이어달리기 일기에서 알맞은 말은? ‘의자에 ___.’",
    "앉았다",
    ["안잤다", "얹었다"],
    ["교실에 들어와서", "의자에 앉았다"],
    "의자에 몸을 두는 상황이므로 ‘앉았다’가 맞아요.",
    3
  ),
  makeSpec(
    "readPractice-hwp-diary-5",
    "이어달리기 일기에서 알맞은 말은? ‘선생님께서 그림책을 ___ 주시고’",
    "읽어",
    ["일거", "읽고"],
    ["그림책", "읽어 주시고"],
    "문장 흐름에 가장 자연스럽게 이어지는 말은 ‘읽어’예요.",
    2
  ),
  makeSpec(
    "readPractice-hwp-diary-6",
    "겹받침 낱말을 읽을 때 먼저 하면 좋은 것은?",
    "실제로 소리 내어 읽어 보기",
    ["글자 모양만 보고 넘어가기", "뜻을 생각하지 않고 외우기"],
    ["겹받침 읽기", "소리 내어 읽기"],
    "겹받침 낱말은 실제 발음을 소리 내어 읽어 보면서 익히는 것이 좋아요.",
    4
  )
);

const OCEAN_FLOW_ITEMS = ["페트병", "물휴지", "과자 봉지"];

OCEAN_FLOW_ITEMS.forEach((item, index) => {
  EXTRA_SPECS.oceanArticle.push(
    makeSpec(
      `oceanArticle-hwp-flow-${index + 1}`,
      "글에서 강을 통해 바다로 흘러가는 것으로 나온 것은?",
      item,
      OCEAN_FLOW_ITEMS.filter((entry) => entry !== item).concat(["나무토막"]).slice(0, 2),
      ["강을 통해 바다로", item],
      `글에서는 ${item} 같은 쓰레기가 강을 통해 바다로 흘러간다고 했어요.`,
      2
    )
  );
});

EXTRA_SPECS.oceanArticle.push(
  makeSpec(
    "oceanArticle-hwp-source-1",
    "플라스틱 쓰레기 더미를 만드는 것으로 글에 나온 것은?",
    "그물과 부표",
    ["나뭇잎과 흙", "꽃과 나비"],
    ["그물", "부표", "플라스틱 쓰레기 더미"],
    "바다의 플라스틱 쓰레기 더미는 그물과 부표 같은 것들이 모여 만들어져요.",
    2
  ),
  makeSpec(
    "oceanArticle-hwp-source-2",
    "플라스틱 쓰레기 더미가 점점 커지는 까닭은?",
    "쓰레기가 계속 바다로 흘러들어 가서",
    ["환경 단체가 쓰레기를 더 모아서", "바다가 쓰레기를 만들기 시작해서"],
    ["강을 통해 바다로", "점점 더 커져"],
    "우리가 버린 플라스틱 쓰레기가 계속 바다로 흘러들어 가기 때문에 더미가 커져요.",
    4
  ),
  makeSpec(
    "oceanArticle-hwp-source-3",
    "플라스틱 쓰레기가 바다에 모이는 것을 막으려고 노력하는 사람은?",
    "많은 사람",
    ["아기별", "한 사람도 없다"],
    ["많은 사람이 노력", "바다를 지켜요"],
    "글에서는 플라스틱 쓰레기를 막으려고 많은 사람이 노력한다고 했어요.",
    2
  ),
  makeSpec(
    "oceanArticle-hwp-source-4",
    "환경 단체들이 하는 일로 알맞은 것은?",
    "해안가와 바다의 쓰레기를 모아 없애기",
    ["플라스틱을 강에 더 흘려보내기", "바다를 잠시 덮어 두기"],
    ["환경 단체", "쓰레기를 모아 없애기"],
    "환경 단체들은 해안가와 바다의 플라스틱 쓰레기를 모아 없애기 위해 노력해요.",
    3
  ),
  makeSpec(
    "oceanArticle-hwp-source-5",
    "우리가 실천할 수 있는 일로 알맞은 것은?",
    "일회용 플라스틱을 덜 사용하기",
    ["플라스틱을 더 많이 사기", "아무 곳에나 버리기"],
    ["우리가 함께 노력", "일회용 플라스틱"],
    "평소에 일회용 플라스틱을 덜 사용하는 것이 바다를 지키는 실천이에요.",
    2
  ),
  makeSpec(
    "oceanArticle-hwp-source-6",
    "플라스틱을 재활용하려면 어떻게 해야 할까?",
    "분류해서 버리기",
    ["바닷가에 놓아두기", "강물에 씻어 보내기"],
    ["재활용", "분류해서 버리기"],
    "플라스틱은 재활용할 수 있도록 종류에 맞게 분류해서 버려야 해요.",
    2
  ),
  makeSpec(
    "oceanArticle-hwp-source-7",
    "사진에서 불편해하는 것으로 설명된 것은?",
    "플라스틱 뚜껑에 갇힌 소라",
    ["모래 위에 누운 갈매기", "꽃잎을 물고 있는 나비"],
    ["환경오염 사진", "소라가 불편해함"],
    "지도안에서는 플라스틱 뚜껑에 갇힌 소라 사진을 보며 환경오염 이야기를 나누도록 했어요.",
    4
  ),
  makeSpec(
    "oceanArticle-hwp-source-8",
    "글의 흐름으로 알맞은 것은?",
    "쓰레기가 바다로 흘러가고, 사람들이 막으려 노력한다",
    ["사람들이 먼저 청소하고, 나중에 쓰레기가 생긴다", "바다가 먼저 깨끗해지고, 강으로 쓰레기가 간다"],
    ["강을 통해 바다로", "많은 사람이 노력"],
    "글은 쓰레기가 바다로 흘러드는 문제를 설명한 뒤, 그것을 막기 위한 사람들의 노력을 보여 줘요.",
    5
  ),
  makeSpec(
    "oceanArticle-hwp-source-9",
    "글을 읽고 알 수 있는 바다 모습은?",
    "플라스틱 쓰레기로 오염되고 있어",
    ["항상 아무 쓰레기도 없어", "꽃과 나무만 가득해"],
    ["바다에 쓰레기가 모여 있다고?", "오염"],
    "지도안에서도 바다에 쓰레기가 있어 오염되고 있는 모습이라고 이야기 나누도록 했어요.",
    3
  ),
  makeSpec(
    "oceanArticle-hwp-source-10",
    "바다를 지키기 위한 태도로 알맞은 것은?",
    "문제를 알고 실천 방법을 찾아보기",
    ["바다 일은 상관없다고 생각하기", "쓰레기를 봐도 그냥 지나가기"],
    ["환경오염", "실천 방법"],
    "글의 내용을 이해한 뒤 우리가 실천할 수 있는 방법을 찾는 태도가 중요해요.",
    5
  )
);

const POND_POEM_FACTS = [
  { key: "person", subject: "사람", action: "거꾸로 걸어가", line: "사람이 거꾸로 걸어간다", rank: 2 },
  { key: "cow", subject: "소", action: "거꾸로 따라가", line: "소가 거꾸로 따라간다", rank: 2 },
  { key: "tree", subject: "나무", action: "거꾸로 쳐다봐", line: "나무가 거꾸로 쳐다본다", rank: 2 },
  { key: "birds", subject: "새들", action: "고기처럼 헤엄쳐 다녀", line: "새들이 고기처럼 헤엄쳐 다닌다", rank: 3 },
  { key: "cloud", subject: "구름", action: "방석처럼 깔려 있어", line: "구름이 방석처럼 깔려 있다", rank: 3 },
  { key: "sun", subject: "해님", action: "모닥불처럼 피어올라", line: "해님이 모닥불처럼 피어오른다", rank: 3 }
];

POND_POEM_FACTS.forEach((item, index, all) => {
  EXTRA_SPECS.pondPoem.push(
    makeSpec(
      `pondPoem-hwp-action-${index + 1}`,
      `연못 속에서 ${item.subject}은/는 어떻게 보일까?`,
      item.action,
      all.filter((entry) => entry.key !== item.key).slice(0, 2).map((entry) => entry.action),
      ["연못 속", item.line],
      `시에서는 ${item.subject}이/가 ‘${item.line}’처럼 보인다고 했어요.`,
      item.rank
    ),
    makeSpec(
      `pondPoem-hwp-subject-${index + 1}`,
      `‘${item.action}’ 모습으로 보이는 것은?`,
      item.subject,
      all.filter((entry) => entry.key !== item.key).slice(0, 2).map((entry) => entry.subject),
      ["연못 속", item.line],
      `‘${item.action}’ 모습으로 보이는 것은 ${item.subject}이에요.`,
      Math.min(5, item.rank + 1)
    )
  );
});

EXTRA_SPECS.pondPoem.push(
  makeSpec(
    "pondPoem-hwp-order-1",
    "연못 속에서 가장 먼저 거꾸로 보이는 것은?",
    "사람",
    ["소", "나무"],
    ["연못 속", "사람 → 소 → 나무"],
    "시의 첫째 장면에는 사람이 거꾸로 걸어가는 모습이 나와요.",
    3
  ),
  makeSpec(
    "pondPoem-hwp-order-2",
    "사람 다음에 거꾸로 따라가는 것은?",
    "소",
    ["나무", "해님"],
    ["사람", "소", "연못 속"],
    "사람 다음 장면에서 소가 거꾸로 따라가요.",
    3
  ),
  makeSpec(
    "pondPoem-hwp-order-3",
    "시의 마지막 장면으로 알맞은 것은?",
    "해님이 모닥불처럼 피어오르는 모습",
    ["사람이 거꾸로 걸어가는 모습", "새들이 고기처럼 헤엄치는 모습"],
    ["연못 속", "마지막 장면"],
    "시의 마지막에는 해님이 모닥불처럼 피어오르는 장면이 나와요.",
    4
  ),
  makeSpec(
    "pondPoem-hwp-feeling-1",
    "‘연못 속’에서 가장 두드러지는 느낌은?",
    "신기하고 재미있는 느낌",
    ["몹시 무섭고 떨리는 느낌", "너무 졸리고 지루한 느낌"],
    ["거꾸로", "고기처럼", "모닥불처럼"],
    "연못 속에서는 익숙한 것들이 낯설고 새롭게 보여서 신기하고 재미있는 느낌이 나요.",
    5
  ),
  makeSpec(
    "pondPoem-hwp-feeling-2",
    "연못 속 장면이 특별하게 느껴지는 까닭은?",
    "평소와 다르게 거꾸로 보이기 때문",
    ["모두 잠들어 있기 때문", "한밤중 장면이기 때문"],
    ["거꾸로 걸어가", "거꾸로 따라가", "거꾸로 쳐다봐"],
    "사람과 소와 나무가 평소와 다르게 거꾸로 보여서 더 특별하게 느껴져요.",
    4
  ),
  makeSpec(
    "pondPoem-hwp-feeling-3",
    "시를 읽고 떠오르는 장면으로 알맞은 것은?",
    "연못에 비친 세상이 뒤집혀 보이는 모습",
    ["운동장에서 이어달리기 하는 모습", "바다에 쓰레기가 떠다니는 모습"],
    ["연못 속", "거꾸로 보이는 장면"],
    "이 시는 연못에 비친 세상이 뒤집혀 보이는 장면을 떠올리게 해요.",
    5
  )
);

EXTRA_SPECS.recitation.push(
  makeSpec(
    "recitation-hwp-today-1",
    "‘오늘은 좋은 일이 많을 거야.’에 어울리는 마음은?",
    "기대되고 즐거운 마음",
    ["화가 나고 답답한 마음", "무섭고 떨리는 마음"],
    ["오늘", "좋은 일이 많을 거야"],
    "‘좋은 일이 많을 거야’라고 말하는 장면에서는 기대되고 즐거운 마음이 느껴져요.",
    2
  ),
  makeSpec(
    "recitation-hwp-today-2",
    "시 속 ‘안녕!’에 어울리는 목소리는?",
    "밝고 반갑게 인사하는 목소리",
    ["화난 듯 낮게 누르는 목소리", "졸린 듯 흐릿한 목소리"],
    ["오늘", "안녕!"],
    "‘안녕!’은 반갑게 인사하는 말이어서 밝고 힘 있는 목소리가 잘 어울려요.",
    3
  ),
  makeSpec(
    "recitation-hwp-today-3",
    "시 속 ‘야호!’에 어울리는 목소리는?",
    "크고 우렁찬 목소리",
    ["아주 작고 약한 목소리", "아무 느낌 없는 목소리"],
    ["오늘", "야호!"],
    "지도안과 평가 문제에서도 ‘야호!’는 크고 우렁찬 목소리로 읽는 것이 알맞다고 했어요.",
    3
  ),
  makeSpec(
    "recitation-hwp-today-4",
    "시를 소리 내어 읽기 전에 먼저 하면 좋은 것은?",
    "장면과 마음을 떠올리기",
    ["빨리 읽기만 연습하기", "어려운 받침 개수만 세기"],
    ["시 읽기 전", "장면과 마음"],
    "시를 읽기 전에 장면과 마음을 먼저 떠올리면 분위기를 살려 읽기 쉬워져요.",
    3
  ),
  makeSpec(
    "recitation-hwp-today-5",
    "시 속 인물의 표정을 그릴 때 먼저 생각할 것은?",
    "시를 읽으며 느껴지는 마음",
    ["연필을 어떤 색으로 쓸지", "종이를 몇 장 쓸지"],
    ["시 속 인물의 표정", "마음"],
    "인물의 표정은 시를 읽으며 느껴지는 마음과 연결해서 생각해야 해요.",
    4
  ),
  makeSpec(
    "recitation-hwp-today-6",
    "시 속 인물에게 하고 싶은 말을 생각할 때 중요한 것은?",
    "시의 장면과 마음에 어울리게 말하기",
    ["교실 물건 이름만 말하기", "받침이 어려운 낱말만 말하기"],
    ["시 속 인물에게 하고 싶은 말", "장면과 마음"],
    "시 속 인물에게 할 말은 시의 장면과 마음을 떠올리며 정하는 것이 좋아요.",
    4
  ),
  makeSpec(
    "recitation-hwp-today-7",
    "자신의 경험과 관련지어 시를 바꿔 쓸 때 가장 알맞은 태도는?",
    "내 생활과 비슷한 일을 떠올려 쓰기",
    ["시를 그대로 베껴 쓰기", "시의 분위기와 상관없이 아무 말 쓰기"],
    ["시 바꿔 쓰기", "자신의 경험"],
    "자신의 경험과 관련지어 써야 시의 장면과 마음이 자연스럽게 살아나요.",
    5
  ),
  makeSpec(
    "recitation-hwp-recite-1",
    "배운 내용을 실천할 때 사용할 수 있는 낭송 방법으로 알맞은 것은?",
    "손뼉 치기, 역할 나누기, 몸짓 하기",
    ["모든 시를 똑같은 속도로 읽기", "한 사람만 끝까지 속삭이며 읽기"],
    ["배운 내용을 실천하기", "낭송 방법"],
    "12-13차시에서는 손뼉 치기, 역할 나누기, 몸짓 하기 같은 낭송 방법을 활용해 보도록 했어요.",
    4
  ),
  makeSpec(
    "recitation-hwp-recite-2",
    "시집에서 마음에 드는 시를 찾은 뒤 할 일로 알맞은 것은?",
    "시를 정해 옮겨 쓰기",
    ["바로 책을 덮고 넘어가기", "제목을 숨기고 아무 말이나 적기"],
    ["시집", "마음에 드는 시"],
    "12-13차시 활동에서는 시집에서 마음에 드는 시를 정해 옮겨 쓰도록 했어요.",
    3
  ),
  makeSpec(
    "recitation-hwp-recite-3",
    "시를 고른 뒤 활동지에 함께 적는 것은?",
    "시 제목과 지은이",
    ["오늘 날짜만", "받침 개수만"],
    ["시 제목", "지은이"],
    "활동지에는 낭송할 시의 제목과 지은이를 함께 적도록 되어 있어요.",
    2
  ),
  makeSpec(
    "recitation-hwp-recite-4",
    "활동지에 ‘고른 까닭’을 쓰는 까닭으로 알맞은 것은?",
    "왜 그 시가 마음에 들었는지 떠올리기 위해",
    ["글씨를 많이 쓰기 위해", "틀린 글자를 찾기 위해"],
    ["고른 까닭", "마음에 드는 시"],
    "시를 고른 까닭을 쓰면 내가 왜 그 시를 좋아했는지 분명하게 알 수 있어요.",
    4
  ),
  makeSpec(
    "recitation-hwp-listen-1",
    "친구가 낭송하는 시를 들을 때 상상하면 좋은 것은?",
    "시 속 인물의 마음",
    ["친구의 연필 길이", "교실 바닥 무늬"],
    ["친구들의 시 낭송", "인물의 마음"],
    "친구의 시 낭송을 들을 때는 시 속 인물의 마음을 상상하며 들으면 좋아요.",
    3
  ),
  makeSpec(
    "recitation-hwp-listen-2",
    "친구의 시 낭송을 들을 때 파악하면 좋은 것은?",
    "시의 분위기",
    ["책상 배치", "교실 창문 수"],
    ["친구의 시 낭송", "시의 분위기"],
    "활동지에서도 친구의 낭송을 들으며 시의 분위기를 파악하는지 확인하도록 했어요.",
    3
  ),
  makeSpec(
    "recitation-hwp-listen-3",
    "좋은 낭송을 들을 때 함께 느끼면 좋은 것은?",
    "시의 재미",
    ["문장 부호 개수", "연필심 굵기"],
    ["친구의 시 낭송", "시의 재미"],
    "낭송을 들을 때는 시의 재미를 함께 느끼는 태도도 중요해요.",
    3
  ),
  makeSpec(
    "recitation-hwp-listen-4",
    "스스로 새로운 책을 찾아 읽는 태도로 알맞은 것은?",
    "마음에 드는 시집을 스스로 찾아 읽기",
    ["교과서만 보고 다른 책은 보지 않기", "시는 읽지 않고 제목만 보기"],
    ["스스로 새로운 책 찾기", "시집 읽기"],
    "활동지에서는 스스로 새로운 책을 찾아 읽을 수 있는지도 함께 살펴보게 해요.",
    4
  ),
  makeSpec(
    "recitation-hwp-wind-1",
    "‘바람은 착하지’에서 바람이 신문지 한 장을 끌고 간 곳은?",
    "골목",
    ["운동장", "연못 속"],
    ["바람은 착하지", "신문지 한 장"],
    "지도안에서는 바람이 신문지 한 장을 끌고 골목으로 나갔다고 내용을 파악하게 해요.",
    2
  ),
  makeSpec(
    "recitation-hwp-wind-2",
    "‘바람은 착하지’에서 바람이 신문지로 만든 것은?",
    "목도리",
    ["연필", "종이배"],
    ["바람은 착하지", "목도리"],
    "바람은 신문지로 목도리를 만들었다고 했어요.",
    2
  ),
  makeSpec(
    "recitation-hwp-wind-3",
    "‘힘내렴!’이라고 할 때 바람의 마음으로 알맞은 것은?",
    "따뜻하고 다정한 마음",
    ["화를 내는 마음", "무서워하는 마음"],
    ["힘내렴!", "바람의 마음"],
    "지도안에서는 바람의 마음을 따뜻하고 다정한 마음으로 떠올리게 해요.",
    4
  ),
  makeSpec(
    "recitation-hwp-wind-4",
    "‘바람은 착하지’를 읽고 느낄 수 있는 분위기로 알맞은 것은?",
    "상냥하고 포근한 분위기",
    ["시끄럽고 부산한 분위기", "차갑고 무서운 분위기"],
    ["바람은 착하지", "따뜻한 마음"],
    "바람이 다정하게 도와주는 모습이 그려져서 상냥하고 포근한 분위기가 느껴져요.",
    5
  )
);

const QUESTION_DIFFICULTY_RANKS = {
  sleepPoem: {
    "sleepPoem-base-1": 1,
    "sleepPoem-base-2": 1,
    "sleepPoem-base-3": 1,
    "sleepPoem-base-4": 5,
    "sleepPoem-base-5": 2,
    "sleepPoem-extra-1": 2,
    "sleepPoem-extra-2": 4,
    "sleepPoem-extra-3": 5,
    "sleepPoem-extra-4": 4
  },
  finalConsonant: {
    "finalConsonant-base-1": 1,
    "finalConsonant-base-2": 2,
    "finalConsonant-base-3": 4,
    "finalConsonant-base-4": 5,
    "finalConsonant-base-5": 3,
    "finalConsonant-extra-1": 1,
    "finalConsonant-extra-2": 2,
    "finalConsonant-extra-3": 1,
    "finalConsonant-extra-4": 4
  },
  readPractice: {
    "readPractice-base-1": 2,
    "readPractice-base-2": 2,
    "readPractice-base-3": 2,
    "readPractice-base-4": 4,
    "readPractice-base-5": 4,
    "readPractice-extra-1": 3,
    "readPractice-extra-2": 4,
    "readPractice-extra-3": 2
  },
  oceanArticle: {
    "oceanArticle-base-1": 2,
    "oceanArticle-base-2": 1,
    "oceanArticle-base-3": 1,
    "oceanArticle-base-4": 3,
    "oceanArticle-base-5": 4,
    "oceanArticle-extra-1": 2,
    "oceanArticle-extra-2": 5,
    "oceanArticle-extra-3": 2,
    "oceanArticle-extra-4": 4
  },
  pondPoem: {
    "pondPoem-base-1": 2,
    "pondPoem-base-2": 2,
    "pondPoem-base-3": 3,
    "pondPoem-base-4": 1,
    "pondPoem-base-5": 1,
    "pondPoem-extra-1": 2,
    "pondPoem-extra-2": 5,
    "pondPoem-extra-3": 4,
    "pondPoem-extra-4": 4
  },
  recitation: {
    "recitation-base-1": 2,
    "recitation-base-2": 2,
    "recitation-base-3": 2,
    "recitation-base-4": 3,
    "recitation-base-5": 4,
    "recitation-extra-1": 5,
    "recitation-extra-2": 3,
    "recitation-extra-3": 4
  }
};

function finalizeCategoryBank(category) {
  const specs = [
    ...buildStageCardSpecs(category),
    ...(EXTRA_SPECS[category] || [])
  ];
  const answerPool = specs.map((spec) => spec.options[spec.answer]);

  const rankMap = QUESTION_DIFFICULTY_RANKS[category] || {};

  const questions = specs.map((spec, index) => {
    const question = createQuestion(
      category,
      spec.id || `${category}-${index + 1}`,
      spec.prompt,
      spec.options,
      spec.answer,
      spec.lines || [],
      spec.explanation || "",
      answerPool.filter((_, answerIndex) => answerIndex !== index)
    );

    question.difficultyRank = spec.rank ?? rankMap[question.id] ?? 3;
    question.passageScene = resolvePassageSceneForQuestion(category, question.id);
    return question;
  });

  return createDifficultyBank(questions);
}

const DISPLAY_QUESTION_BANK = {
  sleepPoem: finalizeCategoryBank("sleepPoem"),
  finalConsonant: finalizeCategoryBank("finalConsonant"),
  readPractice: finalizeCategoryBank("readPractice"),
  oceanArticle: finalizeCategoryBank("oceanArticle"),
  pondPoem: finalizeCategoryBank("pondPoem"),
  recitation: finalizeCategoryBank("recitation")
};
