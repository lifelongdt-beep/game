const GROWTH_STAGES = [
  { name: "장면 씨앗", title: "시의 장면을 찾는 장면 씨앗", threshold: 0, accent: "#7ef0c2" },
  { name: "받침 새싹", title: "받침 읽기가 자라는 받침 새싹", threshold: 5, accent: "#7cc7ff" },
  { name: "분위기 돛배", title: "분위기를 읽는 돛배가 출발했어요", threshold: 10, accent: "#ffd66e" },
  { name: "낭송 별빛", title: "4단원을 완성하는 낭송 별빛", threshold: 15, accent: "#ff9ad2" }
];

const PLAYER_RETRY_DELAY_MS = 900;
const PLAYER_CORRECT_DELAY_MS = 1500;
const PLAYER_EXPLANATION_DELAY_MS = 5000;
const PLAYER_EXTRA_CHANCES = 2;

const DEFAULT_CHARACTER_PHOTO_ASPECT = 1;

const state = {
  category: "mixed",
  timer: 60,
  playerCount: 5,
  players: createPlayers(5),
  screen: "start",
  timerLeft: 0,
  timerHandle: null,
  audioContext: null,
  sessionToken: 0,
  gameEnded: false,
  totalCorrect: 0,
  totalAnswered: 0,
  characterPhotoUrl: CHARACTER_PHOTO_PATH,
  characterPhotoLabel: CHARACTER_PHOTO_PATH,
  characterPhotoAspect: DEFAULT_CHARACTER_PHOTO_ASPECT,
  characterObjectUrl: null,
  scores: createScoreState(createPlayers(5))
};

const startScreen = document.getElementById("startScreen");
const gameScreen = document.getElementById("gameScreen");
const resultScreen = document.getElementById("resultScreen");
const categoryChoices = document.getElementById("categoryChoices");
const timerChoices = document.getElementById("timerChoices");
const playerCountChoices = document.getElementById("playerCountChoices");
const selectionSummary = document.getElementById("selectionSummary");
const characterPhotoInput = document.getElementById("characterPhotoInput");
const characterPhotoStatus = document.getElementById("characterPhotoStatus");
const startGameButton = document.getElementById("startGameButton");
const settingsBadge = document.getElementById("settingsBadge");
const timerValue = document.getElementById("timerValue");
const timerFill = document.getElementById("timerFill");
const progressValue = document.getElementById("progressValue");
const growthStageBadge = document.getElementById("growthStageBadge");
const growthHeadline = document.getElementById("growthHeadline");
const growthSubline = document.getElementById("growthSubline");
const growthMeterFill = document.getElementById("growthMeterFill");
const characterShell = document.getElementById("characterShell");
const playerBoard = document.getElementById("playerBoard");
const winnerHeadline = document.getElementById("winnerHeadline");
const winnerSummary = document.getElementById("winnerSummary");
const resultGrid = document.getElementById("resultGrid");
const restartButton = document.getElementById("restartButton");
const backToHomeButton = document.getElementById("backToHomeButton");
const blogLink = document.getElementById("blogLink");
const homeButton = document.getElementById("homeButton");
const fullscreenButton = document.getElementById("fullscreenButton");
const celebrationLayer = document.getElementById("celebrationLayer");
const celebrationBanner = document.getElementById("celebrationBanner");

blogLink.href = BLOG_URL;

init();

function init() {
  playerBoard.addEventListener("pointerdown", handlePlayerAnswer);
  startGameButton.addEventListener("click", startGame);
  restartButton.addEventListener("click", startGame);
  backToHomeButton.addEventListener("click", goHome);
  homeButton.addEventListener("click", goHome);
  fullscreenButton.addEventListener("click", toggleFullscreen);
  document.addEventListener("fullscreenchange", syncFullscreenButton);
  window.addEventListener("beforeunload", releaseCharacterPhotoUrl);

  if (characterPhotoInput) {
    characterPhotoInput.addEventListener("change", handleCharacterPhotoChange);
  }

  renderStartControls();
  renderCharacterPhotoStatus();
  renderGrowthPanel();
  renderPlayerBoard();
  syncFullscreenButton();
}

function renderStartControls() {
  renderChoiceButtons(categoryChoices, CATEGORY_OPTIONS, state.category, (value) => {
    state.category = value;
    renderStartControls();
  });

  renderChoiceButtons(timerChoices, TIMER_OPTIONS, state.timer, (value) => {
    state.timer = value;
    renderStartControls();
  });

  renderChoiceButtons(playerCountChoices, PLAYER_COUNT_OPTIONS, state.playerCount, (value) => {
    state.playerCount = value;
    state.players = createPlayers(value);
    renderStartControls();
  });

  selectionSummary.innerHTML = [
    summaryPill("문제", CATEGORY_NAMES[state.category]),
    summaryPill("전체 시간", `${state.timer}초`),
    summaryPill("참여 인원", `${state.playerCount}명`)
  ].join("");
}

function renderChoiceButtons(container, options, selectedValue, onSelect) {
  if (!container) {
    return;
  }

  container.innerHTML = "";

  options.forEach((option) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "choice-button";
    if (String(option.value) === String(selectedValue)) {
      button.classList.add("is-selected");
    }
    button.innerHTML = `<strong>${option.label}</strong><span>${option.description}</span>`;
    button.addEventListener("click", () => onSelect(option.value));
    container.appendChild(button);
  });
}

function summaryPill(label, value) {
  return `<div class="summary-pill"><span>${label}</span><strong>${value}</strong></div>`;
}

function handleCharacterPhotoChange(event) {
  const file = event.target.files?.[0];
  if (!file) {
    return;
  }

  releaseCharacterPhotoUrl();
  state.characterObjectUrl = URL.createObjectURL(file);
  state.characterPhotoUrl = state.characterObjectUrl;
  state.characterPhotoLabel = file.name;
  loadCharacterPhotoAspect(state.characterPhotoUrl, () => {
    renderCharacterPhotoStatus();
    renderGrowthPanel();
  });
  event.target.value = "";
}

function releaseCharacterPhotoUrl() {
  if (!state.characterObjectUrl) {
    return;
  }

  URL.revokeObjectURL(state.characterObjectUrl);
  state.characterObjectUrl = null;
}

function loadCharacterPhotoAspect(src, onComplete) {
  const image = new Image();

  image.addEventListener("load", () => {
    state.characterPhotoAspect = image.naturalWidth > 0 && image.naturalHeight > 0
      ? image.naturalWidth / image.naturalHeight
      : DEFAULT_CHARACTER_PHOTO_ASPECT;
    onComplete();
  });

  image.addEventListener("error", () => {
    state.characterPhotoAspect = DEFAULT_CHARACTER_PHOTO_ASPECT;
    onComplete();
  });

  image.src = src;
}

function renderCharacterPhotoStatus() {
  if (!characterPhotoStatus) {
    return;
  }

  const sourceText = state.characterObjectUrl
    ? "현재 주인공 사진: 가져온 사진"
    : `현재 주인공 사진: ${CHARACTER_PHOTO_PATH}`;

  characterPhotoStatus.textContent = sourceText;
}

function startGame() {
  primeAudio();
  state.sessionToken += 1;
  state.gameEnded = false;
  state.totalCorrect = 0;
  state.totalAnswered = 0;

  clearTimers();
  clearPlayerDelays();
  resetCelebration();

  state.players = createPlayers(state.playerCount);
  state.scores = createScoreState(state.players);
  state.timerLeft = state.timer;

  switchScreen("game");
  updateGameStatus();
  renderGrowthPanel();
  renderPlayerBoard();
}

function goHome() {
  state.sessionToken += 1;
  state.gameEnded = false;
  clearTimers();
  clearPlayerDelays();
  resetCelebration();
  switchScreen("start");
  renderStartControls();
}

function switchScreen(screen) {
  state.screen = screen;
  startScreen.classList.toggle("active", screen === "start");
  gameScreen.classList.toggle("active", screen === "game");
  resultScreen.classList.toggle("active", screen === "result");
}

function buildQuestionPool(category, difficulty) {
  return category === "mixed"
    ? CATEGORY_KEYS.flatMap((key) => DISPLAY_QUESTION_BANK[key][difficulty])
    : [...DISPLAY_QUESTION_BANK[category][difficulty]];
}

function getReadyPlayerCount() {
  return state.players.filter((player) => Boolean(state.scores[player.id]?.difficulty)).length;
}

function areAllPlayersReady() {
  return state.players.length > 0 && getReadyPlayerCount() === state.players.length;
}

function maybeStartTimer() {
  if (state.gameEnded || state.timerHandle || !areAllPlayersReady()) {
    return;
  }

  state.timerLeft = state.timer;
  updateGameStatus();
  state.timerHandle = window.setInterval(() => {
    state.timerLeft -= 1;
    updateGameStatus();
    if (state.timerLeft <= 0) {
      endGame();
    }
  }, 1000);
}

function getSceneSignature(question) {
  if (!question?.scene) {
    return "";
  }

  return JSON.stringify(question.scene);
}

function assignNextQuestion(playerId) {
  const playerState = state.scores[playerId];
  const pool = shuffle([...(playerState.questionPool || [])]);

  playerState.currentQuestion = null;
  playerState.locked = false;
  playerState.lastAnswer = null;
  playerState.revealCorrect = null;
  playerState.lastOutcome = null;
  playerState.wrongAttemptsCurrent = 0;
  playerState.isCelebrating = false;
  playerState.celebrationText = "";
  playerState.isShaking = false;
  playerState.showExplanation = false;
  playerState.explanationTitle = "";
  playerState.explanationBody = "";

  if (!playerState.difficulty || pool.length === 0) {
    playerState.status = playerState.difficulty ? "문제 준비 중" : "난이도 고르기";
    return;
  }

  const activeQuestions = state.players
    .filter((player) => player.id !== playerId)
    .map((player) => state.scores[player.id].currentQuestion)
    .filter(Boolean);
  const activeIds = new Set(activeQuestions.map((question) => question.id));
  const activePrompts = new Set(activeQuestions.map((question) => question.prompt));
  const activeScenes = new Set(activeQuestions.map(getSceneSignature));
  const seenIds = new Set(playerState.history);
  const recentIds = new Set(playerState.history.slice(-3));

  let candidates = pool.filter((question) => !activeIds.has(question.id) && !recentIds.has(question.id));
  candidates = candidates.filter((question) => (
    !activePrompts.has(question.prompt)
    && !activeScenes.has(getSceneSignature(question))
  ));

  if (candidates.length === 0) {
    candidates = pool.filter((question) => !activeIds.has(question.id) && !seenIds.has(question.id));
  }

  if (candidates.length === 0) {
    candidates = pool.filter((question) => !activeIds.has(question.id));
  }

  if (candidates.length === 0) {
    candidates = pool;
  }

  playerState.currentQuestion = candidates[0] || null;
  playerState.status = playerState.currentQuestion ? "문제 푸는 중" : "문제 준비 완료";
}

function updateGameStatus() {
  const stageInfo = getGrowthStageInfo();
  const readyCount = getReadyPlayerCount();
  const readinessText = areAllPlayersReady()
    ? "개인별 난이도 완료"
    : `난이도 선택 ${readyCount}/${state.players.length}`;
  settingsBadge.textContent = `${CATEGORY_NAMES[state.category]} · 전체 ${state.timer}초 · ${state.playerCount}명 · ${readinessText}`;
  progressValue.textContent = areAllPlayersReady()
    ? `총 정답 ${state.totalCorrect}개`
    : `난이도 선택 ${readyCount}명`;
  growthStageBadge.textContent = stageInfo.stage.name;
  timerValue.textContent = String(Math.max(0, state.timerLeft)).padStart(2, "0");
  timerFill.style.width = `${(Math.max(0, state.timerLeft) / state.timer) * 100}%`;
}

function renderGrowthPanel() {
  const stageInfo = getGrowthStageInfo();
  if (growthHeadline) {
    growthHeadline.textContent = stageInfo.stage.title;
  }
  if (growthSubline) {
    growthSubline.textContent = `현재 ${stageInfo.stage.name} 단계 · 총 정답 ${state.totalCorrect}개 · 친구 ${state.players.length}명이 각자 다른 국어 문제를 풀고 있어요.`;
  }
  if (growthMeterFill) {
    growthMeterFill.style.width = `${stageInfo.progress}%`;
  }
  if (characterShell) {
    characterShell.innerHTML = renderCharacterIllustrationCompact(stageInfo);
  }
}

function getGrowthStageInfo() {
  let stageIndex = 0;
  GROWTH_STAGES.forEach((stage, index) => {
    if (state.totalCorrect >= stage.threshold) {
      stageIndex = index;
    }
  });
  const stage = GROWTH_STAGES[stageIndex];
  const nextThreshold = GROWTH_STAGES[stageIndex + 1]?.threshold ?? stage.threshold;
  const progress = stageIndex === GROWTH_STAGES.length - 1
    ? 100
    : ((state.totalCorrect - stage.threshold) / (nextThreshold - stage.threshold)) * 100;

  return {
    stageIndex,
    stage,
    progress: Math.max(0, Math.min(100, progress)),
    cheerLevel: Math.min(1, state.totalCorrect / 12)
  };
}

function renderCharacterIllustration(stageInfo) {
  const badgeColors = ["#ff8f3f", "#2d70f4", "#1bb6a5", "#9b7cff"];
  const stageShapes = [
    "triangle",
    "square",
    "circle",
    "trapezoid"
  ].map((kind) => `<div style="width:40px;height:40px;">${shapeSVG({ kind }, "shape-svg")}</div>`);

  const photoMarkup = state.characterPhotoUrl && state.characterPhotoUrl !== CHARACTER_PHOTO_PATH
    ? `
      <div style="width:128px;height:128px;border-radius:32px;overflow:hidden;border:4px solid rgba(255,255,255,0.75);box-shadow:0 18px 28px rgba(0,0,0,0.18);">
        <img src="${state.characterPhotoUrl}" alt="${stageInfo.stage.name}" style="width:100%;height:100%;object-fit:cover;">
      </div>
    `
    : `
      <div style="width:128px;height:128px;border-radius:32px;background:linear-gradient(145deg,#fdf7ff,#ddf2ff);display:grid;place-items:center;border:4px solid rgba(255,255,255,0.7);box-shadow:0 18px 28px rgba(0,0,0,0.18);">
        <div style="width:86px;height:86px;border-radius:24px;background:${stageInfo.stage.accent};display:grid;place-items:center;transform:rotate(-6deg);">
          <div style="display:grid;grid-template-columns:repeat(2,40px);gap:6px;">
            ${stageShapes.join("")}
          </div>
        </div>
      </div>
    `;

  const chips = GROWTH_STAGES.map((stage, index) => `
    <div style="
      padding:8px 12px;
      border-radius:999px;
      font-size:0.82rem;
      font-weight:700;
      color:${index <= stageInfo.stageIndex ? "#081425" : "#dce8ff"};
      background:${index <= stageInfo.stageIndex ? stage.accent : "rgba(255,255,255,0.12)"};
      border:1px solid ${index <= stageInfo.stageIndex ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.16)"};
    ">${stage.name}</div>
  `).join("");

  return `
    <div style="display:grid;gap:16px;justify-items:center;">
      ${photoMarkup}
      <div style="display:grid;gap:10px;justify-items:center;text-align:center;">
        <strong style="font-size:1.15rem;color:#f7fbff;">${stageInfo.stage.name}</strong>
              <span style="color:#dce8ff;font-size:0.92rem;">정답이 늘어날수록 분위기 탐험 친구가 더 반짝여요.</span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;max-width:320px;">
        ${chips}
      </div>
    </div>
  `;
}

function renderCharacterIllustrationCompact(stageInfo) {
  const stageShapes = [
    "triangle",
    "square",
    "circle",
    "trapezoid"
  ].map((kind) => `<div class="growth-stage-shape">${shapeSVG({ kind }, "shape-svg")}</div>`).join("");

  const photoMarkup = state.characterPhotoUrl && state.characterPhotoUrl !== CHARACTER_PHOTO_PATH
    ? `
      <div class="growth-stage-portrait is-photo">
        <img class="growth-stage-photo" src="${state.characterPhotoUrl}" alt="${stageInfo.stage.name}">
      </div>
    `
    : `
      <div class="growth-stage-portrait is-illustrated">
        <div class="growth-stage-shape-cluster" style="--stage-accent:${stageInfo.stage.accent};">
          ${stageShapes}
        </div>
      </div>
    `;

  const chips = GROWTH_STAGES.map((stage, index) => `
    <div class="growth-stage-chip ${index <= stageInfo.stageIndex ? "is-active" : ""}" style="--chip-accent:${stage.accent};">${stage.name}</div>
  `).join("");

  return `
    <div class="growth-stage-card">
      <div class="growth-stage-visual">
        ${photoMarkup}
      </div>
      <div class="growth-stage-body">
        <div class="growth-stage-copy">
          <strong class="growth-stage-name">${stageInfo.stage.name}</strong>
              <span class="growth-stage-caption">정답이 늘어날수록 분위기 탐험 친구가 더 반짝여요.</span>
        </div>
        <div class="growth-stage-chip-list">
          ${chips}
        </div>
      </div>
    </div>
  `;
}

function applyPlayerDifficultySelection(playerId, difficulty) {
  const playerState = state.scores[playerId];

  if (!playerState || playerState.difficulty || state.gameEnded) {
    return;
  }

  playerState.difficulty = difficulty;
  playerState.questionPool = buildQuestionPool(state.category, difficulty);

  if (areAllPlayersReady()) {
    state.players.forEach((player) => assignNextQuestion(player.id));
    maybeStartTimer();
  } else {
    playerState.status = `${DIFFICULTY_NAMES[difficulty]} 선택 완료`;
  }

  updateGameStatus();
  renderPlayerBoard();
}

function handlePlayerAnswer(event) {
  if (state.screen !== "game" || state.gameEnded) {
    return;
  }

  const passageScrollButton = event.target.closest(".passage-scroll-button");
  if (passageScrollButton) {
    event.preventDefault();
    scrollPassageViewport(passageScrollButton);
    return;
  }

  const difficultyButton = event.target.closest(".difficulty-select-button");
  if (difficultyButton) {
    applyPlayerDifficultySelection(
      difficultyButton.dataset.player,
      difficultyButton.dataset.difficulty
    );
    return;
  }

  const button = event.target.closest(".answer-button");
  if (!button) {
    return;
  }

  primeAudio();

  const playerId = button.dataset.player;
  const optionIndex = Number(button.dataset.option);
  const playerState = state.scores[playerId];
  const player = state.players.find((item) => item.id === playerId);

  if (playerState.locked || !playerState.currentQuestion) {
    return;
  }

  const isCorrect = optionIndex === playerState.currentQuestion.answer;
  const answeredQuestion = playerState.currentQuestion;
  const sessionToken = state.sessionToken;

  playerState.locked = true;
  playerState.lastAnswer = optionIndex;
  playerState.showExplanation = false;
  playerState.explanationTitle = "";
  playerState.explanationBody = "";
  state.totalAnswered += 1;

  if (isCorrect) {
    const earned = SCORE_BY_DIFFICULTY[playerState.difficulty] || SCORE_BY_DIFFICULTY.mid;
    playerState.score += earned;
    playerState.correct += 1;
    playerState.status = playerState.wrongAttemptsCurrent > 0 ? `재도전 성공 +${earned}점` : `정답 +${earned}점`;
    playerState.revealCorrect = answeredQuestion.answer;
    playerState.lastOutcome = "correct";
    playerState.history.push(answeredQuestion.id);
    playerState.wrongAttemptsCurrent = 0;
    playerState.isCelebrating = true;
    playerState.isShaking = false;
    state.totalCorrect += 1;
    playerState.celebrationText = `${player?.soundText || "딩동"}! 성장 ${getAnimalGrowthState(playerState.correct).level}단계!`;

    updateGameStatus();
    renderGrowthPanel();
    triggerCelebration(playerId);
    playAnimalSound(player);
  } else {
    playerState.wrong += 1;
    playerState.isCelebrating = false;

    if (playerState.wrongAttemptsCurrent < PLAYER_EXTRA_CHANCES) {
      playerState.wrongAttemptsCurrent += 1;
      const chancesLeft = PLAYER_EXTRA_CHANCES - playerState.wrongAttemptsCurrent + 1;
      playerState.revealCorrect = null;
      playerState.lastOutcome = "retry";
      playerState.isShaking = true;
      playerState.status = `오답! ${chancesLeft}번 더 도전`;
      triggerWrongAnswerFeedback();
    } else {
      playerState.wrongAttemptsCurrent += 1;
      playerState.revealCorrect = answeredQuestion.answer;
      playerState.lastOutcome = "wrong-final";
      playerState.isShaking = false;
      playerState.showExplanation = true;
      playerState.explanationTitle = `정답은 ${OPTION_LABELS[answeredQuestion.answer]}번 ${compactOptionText(answeredQuestion.options[answeredQuestion.answer])}`;
      playerState.explanationBody = buildFriendlyExplanation(answeredQuestion);
      playerState.status = "풀이 확인 5초";
      playerState.history.push(answeredQuestion.id);
    }
  }

  renderPlayerBoard();

  const delay = playerState.lastOutcome === "retry"
    ? PLAYER_RETRY_DELAY_MS
    : playerState.lastOutcome === "wrong-final"
      ? PLAYER_EXPLANATION_DELAY_MS
      : PLAYER_CORRECT_DELAY_MS;
  if (playerState.lastOutcome !== "retry") {
    playerState.pendingHandle = window.setTimeout(() => {
      if (sessionToken !== state.sessionToken || state.gameEnded) {
        return;
      }
      assignNextQuestion(playerId);
      renderPlayerBoard();
    }, delay);
  } else {
    playerState.pendingHandle = window.setTimeout(() => {
      if (sessionToken !== state.sessionToken || state.gameEnded) {
        return;
      }
      playerState.locked = false;
      playerState.isShaking = false;
      playerState.status = "다시 골라 보세요";
      renderPlayerBoard();
    }, delay);
  }
}

function getAnimalGrowthState(correctCount) {
  if (correctCount >= 7) {
    return { level: 5, title: "별빛 점프", scale: 1.26, glow: 1 };
  }

  if (correctCount >= 5) {
    return { level: 4, title: "반짝 스타", scale: 1.2, glow: 0.84 };
  }

  if (correctCount >= 3) {
    return { level: 3, title: "쑥쑥 성장", scale: 1.14, glow: 0.68 };
  }

  if (correctCount >= 1) {
    return { level: 2, title: "새싹 미소", scale: 1.08, glow: 0.52 };
  }

  return { level: 1, title: "준비 씨앗", scale: 1, glow: 0.36 };
}

function renderAnimalStage(player, playerState) {
  const growthState = getAnimalGrowthState(playerState.correct);
  const speech = !playerState.difficulty
    ? "난이도 골라요!"
    : !playerState.currentQuestion && !state.gameEnded
      ? "친구 기다려요!"
    : playerState.isCelebrating
      ? `${player.soundText}! 신나요!`
      : playerState.isShaking
        ? "다시 도전!"
        : playerState.correct > 0
          ? `성장 ${growthState.level}단계`
          : "준비 완료";

  const classNames = ["animal-stage", `animal-${player.voice}`];
  if (playerState.isCelebrating) {
    classNames.push("is-celebrating");
  }
  if (playerState.correct > 0) {
    classNames.push("is-grown");
  }

  return `
    <div class="${classNames.join(" ")}" style="--animal-scale:${growthState.scale};--animal-glow:${growthState.glow};">
      <div class="animal-bubble">${speech}</div>
      <div class="animal-avatar-shell" aria-hidden="true">
        <span class="animal-sparkle animal-sparkle--a">✦</span>
        <span class="animal-sparkle animal-sparkle--b">✧</span>
        <span class="animal-sparkle animal-sparkle--c">★</span>
        <div class="animal-avatar">
          <span class="animal-emoji">${player.avatar}</span>
          <span class="animal-face">
            <span class="animal-eye animal-eye--left"></span>
            <span class="animal-eye animal-eye--right"></span>
            <span class="animal-cheek animal-cheek--left"></span>
            <span class="animal-cheek animal-cheek--right"></span>
            <span class="animal-mouth"></span>
          </span>
        </div>
      </div>
      <div class="animal-name">${player.name}</div>
      <div class="animal-growth-badge">성장 ${growthState.level}단계 · ${growthState.title}</div>
    </div>
  `;
}

function shouldShowPassageScene(playerState, question) {
  return Boolean(
    question?.passageScene
    && !state.gameEnded
    && !playerState.isCelebrating
    && !playerState.showExplanation
    && playerState.lastOutcome !== "correct"
  );
}

function renderPassageScene(scene, playerId, questionId) {
  return `
    <div class="scene-shell scene-passage-shell" data-player="${playerId}" data-question="${questionId}">
      <div class="passage-viewport" data-player="${playerId}" data-question="${questionId}">
        <div class="passage-header">
          <span class="passage-kicker">${scene.kicker || "지문 읽기"}</span>
          <strong class="passage-title">${scene.title || "문제 지문"}</strong>
        </div>
        <div class="passage-text">
          ${scene.lines.map((line) => `<p class="passage-line">${line}</p>`).join("")}
        </div>
        <div class="passage-scroll-controls">
          <button type="button" class="passage-scroll-button passage-scroll-button--up" data-player="${playerId}" data-question="${questionId}" data-direction="up" aria-label="지문 위로 스크롤">▲</button>
          <button type="button" class="passage-scroll-button passage-scroll-button--down" data-player="${playerId}" data-question="${questionId}" data-direction="down" aria-label="지문 아래로 스크롤">▼</button>
        </div>
      </div>
    </div>
  `;
}

function renderPlayerScene(player, playerState, question, isChoosingDifficulty, isWaitingForStart) {
  if (question && shouldShowPassageScene(playerState, question)) {
    return renderPassageScene(question.passageScene, player.id, question.id);
  }

  if (question || isChoosingDifficulty || isWaitingForStart || !state.gameEnded) {
    return renderAnimalStage(player, playerState);
  }

  return `<div class="player-finished">${player.avatar} 수고했어요!</div>`;
}

function renderPlayerBoard() {
  preservePassageScrollPositions();
  playerBoard.style.setProperty("--player-columns", String(Math.min(state.players.length, 6)));
  playerBoard.dataset.playerCount = String(state.players.length);
  playerBoard.innerHTML = state.players.map((player) => {
    const playerState = state.scores[player.id];
    const question = playerState.currentQuestion;
    const isChoosingDifficulty = !playerState.difficulty && !state.gameEnded;
    const isWaitingForStart = !isChoosingDifficulty && !question && !state.gameEnded;
    const isBasicPrompt = playerState.difficulty === "low" && Boolean(question);
    const isPassagePrompt = Boolean(question && shouldShowPassageScene(playerState, question));
    const buttons = OPTION_LABELS.map((label, index) => {
      const classNames = ["answer-button"];

      if (playerState.lastAnswer === index) {
        classNames.push("is-selected");
        if (playerState.lastOutcome === "correct" && playerState.revealCorrect === index) {
          classNames.push("is-correct");
        } else if (playerState.lastOutcome === "retry" || playerState.lastOutcome === "wrong-final") {
          classNames.push("is-wrong");
        }
      } else if (
        playerState.revealCorrect === index &&
        playerState.locked &&
        (playerState.lastOutcome === "correct" || playerState.lastOutcome === "wrong-final")
      ) {
        classNames.push("is-correct");
      }

      return `
        <button
          type="button"
          class="${classNames.join(" ")}"
          data-player="${player.id}"
          data-option="${index}"
          ${state.gameEnded || playerState.locked || !question ? "disabled" : ""}
        >
          <span class="answer-label">${label}</span>
          <span class="answer-copy">${question ? question.options[index] : ""}</span>
        </button>
      `;
    }).join("");
    const difficultyButtons = DIFFICULTY_OPTIONS.map((option) => `
      <button
        type="button"
        class="difficulty-select-button difficulty-select-button--${option.value}"
        data-player="${player.id}"
        data-difficulty="${option.value}"
      >
        <strong>${option.label}</strong>
        <span>${option.description}</span>
      </button>
    `).join("");

    const explanationAnswer = question && playerState.revealCorrect !== null
      ? `
          <div class="player-explanation-answer">
            <span class="player-explanation-answer-label">${OPTION_LABELS[playerState.revealCorrect]}</span>
            <span class="player-explanation-answer-text">${question.options[playerState.revealCorrect]}</span>
          </div>
        `
      : "";

    const answerAreaMarkup = isChoosingDifficulty
      ? `
          <div class="difficulty-select-grid">
            <p class="difficulty-select-note">문제 나오기 전에 ${player.name}의 난이도를 골라 주세요.</p>
            ${difficultyButtons}
          </div>
        `
      : isWaitingForStart
        ? `
          <div class="difficulty-select-grid difficulty-select-grid--waiting">
            <p class="difficulty-select-note">${player.name} · ${DIFFICULTY_NAMES[playerState.difficulty]} 선택 완료</p>
            <div class="player-wait-card">다른 친구들이 난이도를 고르는 중이에요.<br>모두 고르면 동시에 시작해요.</div>
          </div>
        `
      : playerState.showExplanation
        ? `
          <div class="player-explanation">
            <strong>${playerState.explanationTitle}</strong>
            ${explanationAnswer}
            <p>${playerState.explanationBody}</p>
          </div>
        `
        : `<div class="answer-grid">${buttons}</div>`;

    const successStamp = playerState.isCelebrating
      ? `<div class="player-stamp" aria-hidden="true"><span>참 잘했어요</span></div>`
      : "";

    const celebrationNote = playerState.isCelebrating && playerState.celebrationText
      ? `<div class="player-celebration-note">${playerState.celebrationText}</div>`
      : "";

    return `
      <article class="player-panel ${isBasicPrompt ? "player-panel--basic" : ""} ${isPassagePrompt ? "player-panel--passage" : ""} ${playerState.isCelebrating ? "is-celebrating" : ""} ${playerState.isShaking ? "is-shaking" : ""}" style="background:${player.color}">
        <div class="player-head">
          <div class="player-head-copy">
            <div class="player-identity">
              <span class="player-avatar-chip" aria-hidden="true">${player.avatar}</span>
              <strong>${player.name}</strong>
            </div>
            <span class="player-status-badge">${playerState.status}</span>
          </div>
          <span class="player-score">${playerState.score}점</span>
        </div>
        <div class="player-question ${isBasicPrompt ? "player-question--basic" : ""}">
          <p class="player-kicker">${isChoosingDifficulty ? "첫 화면 · 난이도 선택" : isWaitingForStart ? "난이도 선택 완료" : question ? `${resolveQuestionCategory(question)} · ${DIFFICULTY_NAMES[playerState.difficulty]}` : "놀이 마침"}</p>
          <p class="player-prompt ${isBasicPrompt ? "player-prompt--basic" : ""}">${isChoosingDifficulty ? `${player.name}의 난이도를 골라 주세요.` : isWaitingForStart ? `${player.name}은 ${DIFFICULTY_NAMES[playerState.difficulty]} 준비가 끝났어요.` : question ? question.prompt : "전체 시간이 끝났어요."}</p>
        </div>
        <div class="player-scene">
          ${renderPlayerScene(player, playerState, question, isChoosingDifficulty, isWaitingForStart)}
        </div>
        <div class="player-answer-shell">
          ${answerAreaMarkup}
          ${successStamp}
          ${celebrationNote}
        </div>
      </article>
    `;
  }).join("");
  restorePassageScrollPositions();
  syncPassagePanels();
}

function compactOptionText(optionText) {
  return optionText.replace(": ", " ").replace(/\s+/g, " ");
}

function buildFriendlyExplanation(question) {
  if (question.explanation) {
    return question.explanation;
  }

  const category = resolveQuestionCategory(question);
  const correctText = compactOptionText(question.options[question.answer]);
  const categoryRule = {
    "누가 누가 잠자나": "시 속 장소와 대상을 함께 떠올리며 읽으면 장면이 또렷해져요.",
    "쌍받침·겹받침": "받침에 들어간 자음자 수와 소리를 함께 생각하면 훨씬 쉬워져요.",
    "겹받침 읽기": "겹받침 낱말은 실제로 소리 내어 읽는 모습을 떠올리면 덜 헷갈려요.",
    "설명글 이해": "설명글은 중요한 낱말과 실천 방법을 차례대로 찾으면 뜻이 분명해져요.",
    "연못 속": "비유한 말을 장면으로 바꾸어 떠올리면 시의 분위기가 살아나요.",
    "낭송과 분위기": "낭송은 장면, 마음, 읽는 목소리를 함께 생각하면 더 자연스러워져요."
  }[category] || "문장 속 단서와 보기를 다시 연결해 보면 다음 문제가 더 쉬워져요.";

  if (question.scene?.type === "clues" && Array.isArray(question.scene.lines)) {
    return `${question.scene.lines.join(" ")} 그래서 정답은 ${correctText}예요. ${categoryRule}`;
  }

  if (question.prompt.includes("몇") || correctText.includes("개") || correctText.includes("층")) {
    return `문장 속 단서를 한 줄씩 읽고 연결하면 정답이 보여요. 정답은 ${correctText}예요. ${categoryRule}`;
  }

  if (question.prompt.includes("옳지 않은") || question.prompt.includes("없는") || question.prompt.includes("아닌")) {
    return `보기 하나하나를 기준에 맞게 비교해 보면 알맞은 답을 찾을 수 있어요. 정답은 ${correctText}예요. ${categoryRule}`;
  }

  return `정답은 ${correctText}예요. 문장과 장면을 한 번 더 연결해 보면 다음 문제는 더 빨라질 거예요. ${categoryRule}`;
}

function resolveQuestionCategory(questionOrId) {
  if (questionOrId && typeof questionOrId === "object" && questionOrId.category) {
    return CATEGORY_NAMES[questionOrId.category] || CATEGORY_NAMES.mixed;
  }

  return CATEGORY_NAMES.mixed;
}

function endGame() {
  if (state.gameEnded) {
    return;
  }

  state.gameEnded = true;
  clearTimers();
  clearPlayerDelays();
  renderPlayerBoard();
  showResults();
}

function showResults() {
  switchScreen("result");
  const totalScore = state.players.reduce((sum, player) => sum + state.scores[player.id].score, 0);

  resultGrid.style.setProperty("--result-columns", String(Math.min(state.players.length, 6)));
  winnerHeadline.textContent = state.players.length ? `전체 학생 점수 총합 ${totalScore}점` : "결과를 확인해 보세요";
  winnerSummary.textContent = `친구 ${state.players.length}명 · 총 정답 ${state.totalCorrect}개`;
  resultGrid.innerHTML = state.players.map((player) => {
    const playerState = state.scores[player.id];
    return `
      <article class="result-card">
        <h3>${player.avatar} ${player.name}</h3>
        <p>정답 ${playerState.correct}개 · 오답 ${playerState.wrong}개</p>
        <strong class="result-score">${playerState.score}점</strong>
      </article>
    `;
  }).join("");
}

function createScoreState(players) {
  return players.reduce((accumulator, player) => {
    accumulator[player.id] = {
      difficulty: null,
      questionPool: [],
      score: 0,
      correct: 0,
      wrong: 0,
      currentQuestion: null,
      locked: false,
      lastAnswer: null,
      revealCorrect: null,
      lastOutcome: null,
      wrongAttemptsCurrent: 0,
      isCelebrating: false,
      celebrationText: "",
      isShaking: false,
      showExplanation: false,
      explanationTitle: "",
      explanationBody: "",
      status: "난이도 고르기",
      history: [],
      passageScrollTopByQuestion: {},
      pendingHandle: null
    };
    return accumulator;
  }, {});
}

function preservePassageScrollPositions() {
  playerBoard.querySelectorAll(".passage-viewport").forEach((viewport) => {
    const { player: playerId, question: questionId } = viewport.dataset;
    const playerState = state.scores[playerId];

    if (!playerState || !questionId) {
      return;
    }

    playerState.passageScrollTopByQuestion[questionId] = viewport.scrollTop;
  });
}

function restorePassageScrollPositions() {
  playerBoard.querySelectorAll(".passage-viewport").forEach((viewport) => {
    const { player: playerId, question: questionId } = viewport.dataset;
    const playerState = state.scores[playerId];

    if (!playerState || !questionId) {
      return;
    }

    viewport.scrollTop = playerState.passageScrollTopByQuestion[questionId] || 0;
  });
}

function syncPassagePanel(shell) {
  const viewport = shell.querySelector(".passage-viewport");
  const upButton = shell.querySelector(".passage-scroll-button--up");
  const downButton = shell.querySelector(".passage-scroll-button--down");

  if (!viewport || !upButton || !downButton) {
    return;
  }

  const hasOverflow = viewport.scrollHeight - viewport.clientHeight > 6;
  const nearTop = viewport.scrollTop <= 4;
  const nearBottom = viewport.scrollTop + viewport.clientHeight >= viewport.scrollHeight - 4;

  shell.classList.toggle("has-scroll", hasOverflow);
  upButton.disabled = !hasOverflow || nearTop;
  downButton.disabled = !hasOverflow || nearBottom;
}

function handlePassageViewportScroll(event) {
  const viewport = event.currentTarget;
  const { player: playerId, question: questionId } = viewport.dataset;
  const playerState = state.scores[playerId];

  if (playerState && questionId) {
    playerState.passageScrollTopByQuestion[questionId] = viewport.scrollTop;
  }

  const shell = viewport.closest(".scene-passage-shell");
  if (shell) {
    syncPassagePanel(shell);
  }
}

function syncPassagePanels() {
  playerBoard.querySelectorAll(".passage-viewport").forEach((viewport) => {
    if (viewport.dataset.bound !== "true") {
      viewport.addEventListener("scroll", handlePassageViewportScroll, { passive: true });
      viewport.dataset.bound = "true";
    }
  });

  playerBoard.querySelectorAll(".scene-passage-shell").forEach((shell) => {
    syncPassagePanel(shell);
  });
}

function scrollPassageViewport(button) {
  const shell = button.closest(".scene-passage-shell");
  const viewport = shell?.querySelector(".passage-viewport");

  if (!shell || !viewport) {
    return;
  }

  const direction = button.dataset.direction === "up" ? -1 : 1;
  const scrollStep = Math.max(88, Math.round(viewport.clientHeight * 0.58));
  viewport.scrollTop += scrollStep * direction;

  const { player: playerId, question: questionId } = viewport.dataset;
  const playerState = state.scores[playerId];
  if (playerState && questionId) {
    playerState.passageScrollTopByQuestion[questionId] = viewport.scrollTop;
  }

  syncPassagePanel(shell);
}

function clearTimers() {
  clearInterval(state.timerHandle);
  state.timerHandle = null;
}

function clearPlayerDelays() {
  Object.values(state.scores).forEach((playerState) => {
    clearTimeout(playerState.pendingHandle);
    playerState.pendingHandle = null;
  });
}

function primeAudio() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) {
    return;
  }

  if (!state.audioContext) {
    state.audioContext = new AudioContextClass();
  }

  if (state.audioContext.state === "suspended") {
    state.audioContext.resume().catch(() => {});
  }
}

function playAnimalSound(player) {
  if (!state.audioContext) {
    return;
  }

  const now = state.audioContext.currentTime + 0.01;
  const voice = player?.voice || "puppy";

  if (voice === "kitten") {
    scheduleAnimalTone("triangle", 820, 520, now, 0.32, 0.08);
    scheduleAnimalTone("triangle", 620, 760, now + 0.17, 0.18, 0.05);
    return;
  }

  if (voice === "chick") {
    [0, 0.09, 0.18].forEach((offset) => {
      scheduleAnimalTone("sine", 1280, 980, now + offset, 0.09, 0.045);
    });
    return;
  }

  if (voice === "duck") {
    scheduleAnimalTone("sawtooth", 520, 240, now, 0.16, 0.07);
    scheduleAnimalTone("sawtooth", 420, 210, now + 0.15, 0.16, 0.07);
    return;
  }

  if (voice === "frog") {
    scheduleAnimalTone("square", 210, 120, now, 0.2, 0.08);
    scheduleAnimalTone("square", 180, 105, now + 0.16, 0.22, 0.08);
    return;
  }

  scheduleAnimalTone("square", 340, 180, now, 0.12, 0.08);
  scheduleAnimalTone("square", 280, 150, now + 0.14, 0.12, 0.08);
}

function scheduleAnimalTone(type, startFrequency, endFrequency, startTime, duration, peakGain) {
  const oscillator = state.audioContext.createOscillator();
  const gain = state.audioContext.createGain();

  oscillator.type = type;
  oscillator.frequency.setValueAtTime(startFrequency, startTime);
  oscillator.frequency.exponentialRampToValueAtTime(Math.max(60, endFrequency), startTime + duration);
  gain.gain.setValueAtTime(0.0001, startTime);
  gain.gain.exponentialRampToValueAtTime(peakGain, startTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

  oscillator.connect(gain);
  gain.connect(state.audioContext.destination);
  oscillator.start(startTime);
  oscillator.stop(startTime + duration + 0.02);
}

function triggerWrongAnswerFeedback() {
  if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") {
    navigator.vibrate([90, 50, 90]);
  }
}

function triggerCelebration(playerId) {
  const player = state.players.find((item) => item.id === playerId);
  if (!player) {
    return;
  }

  celebrationBanner.textContent = `${player.name} 정답!`;
  celebrationBanner.classList.add("is-active");
  celebrationLayer.innerHTML = Array.from({ length: 10 }, (_, index) => {
    const left = 8 + (index * 9);
    const delay = index * 0.05;
    const color = ["#ff8f3f", "#ffd565", "#1bb6a5", "#2d70f4", "#9b7cff"][index % 5];
    return `
      <span style="
        position:absolute;
        left:${left}%;
        top:-24px;
        width:12px;
        height:12px;
        border-radius:4px;
        background:${color};
        transform:rotate(${index * 18}deg);
        animation:fall-shape 900ms ease ${delay}s forwards;
      "></span>
    `;
  }).join("");

  window.setTimeout(() => resetCelebration(), 850);
}

function resetCelebration() {
  celebrationLayer.innerHTML = "";
  celebrationBanner.classList.remove("is-active");
  celebrationBanner.textContent = "";
}

async function toggleFullscreen() {
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
    } else {
      await document.documentElement.requestFullscreen();
    }
  } catch (error) {
    console.error("전체 화면 전환 실패", error);
  }
}

function syncFullscreenButton() {
  document.documentElement.classList.toggle("is-fullscreen", Boolean(document.fullscreenElement));
  fullscreenButton.textContent = document.fullscreenElement ? "전체 화면 종료" : "전체 화면";
}

function shuffle(items) {
  for (let index = items.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [items[index], items[swapIndex]] = [items[swapIndex], items[index]];
  }
  return items;
}

function renderScene(scene) {
  if (!scene) {
    return "";
  }

  if (scene.type === "image") {
    return `
      <div class="scene-shell scene-image-shell">
        <img class="scene-image" src="${scene.src}" alt="${scene.alt || "문제 그림"}">
      </div>
    `;
  }

  if (scene.type === "svg") {
    return `
      <div class="scene-shell scene-svg-shell ${scene.className || ""}">
        <svg class="scene-illustration" viewBox="${scene.viewBox || "0 0 320 220"}" role="img" aria-label="${scene.alt || "문제 그림"}">
          ${scene.markup}
        </svg>
      </div>
    `;
  }

  if (scene.type === "single") {
    return `<div class="scene-shell scene-single-shell"><div class="shape-single">${shapeSVG(scene.item, "shape-svg")}</div></div>`;
  }

  if (scene.type === "grid") {
    return `
      <div class="scene-shell scene-grid-shell">
        <div class="shape-grid" style="--columns:${scene.columns || 4}">
          ${scene.items.map((item) => `
            <div class="shape-card">
              ${shapeSVG(item, "shape-svg")}
              ${item.label ? `<small>${item.label}</small>` : ""}
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  if (scene.type === "clues") {
    return `
      <div class="scene-shell scene-clue-shell">
        <div class="clue-stack">${scene.lines.map((line) => `<div class="clue-pill">${line}</div>`).join("")}</div>
      </div>
    `;
  }

  if (scene.type === "groupCount") {
    return `
      <div class="scene-shell scene-group-shell">
        <div class="shape-grid" style="--columns:${scene.groups.length}">
          ${scene.groups.map((group) => `
            <div class="shape-card">
              <small>${group.label}</small>
              <div class="shape-grid" style="--columns:1">
                ${group.items.map((item) => `<div class="shape-card">${shapeSVG(item, "shape-svg")}</div>`).join("")}
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  return "";
}

function shapeSVG(item, className) {
  const fill = SHAPE_FILL[item.kind] || "#8a94a6";
  const rotate = item.rotate || 0;
  const label = item.label ? `<text x="50" y="95" text-anchor="middle" font-size="12" fill="#5a6570" font-weight="700">${item.label}</text>` : "";

  const wrappers = {
    triangle: `<polygon points="50,10 88,82 12,82" fill="${fill}" />`,
    "triangle-right": `<polygon points="18,16 18,84 84,84" fill="${fill}" />`,
    square: `<rect x="18" y="18" width="64" height="64" fill="${fill}" />`,
    rectangle: `<rect x="12" y="26" width="76" height="48" fill="${fill}" />`,
    diamond: `<polygon points="50,10 88,50 50,90 12,50" fill="${fill}" />`,
    trapezoid: `<polygon points="24,20 76,20 90,82 10,82" fill="${fill}" />`,
    circle: `<circle cx="50" cy="50" r="34" fill="${fill}" />`,
    oval: `<ellipse cx="50" cy="50" rx="38" ry="28" fill="${fill}" />`,
    semicircle: `<path d="M15,68 A35,35 0 0 1 85,68 L15,68 Z" fill="${fill}" />`,
    pentagon: `<polygon points="50,10 88,36 74,82 26,82 12,36" fill="${fill}" />`,
    "open-triangle": `<polyline points="50,12 88,82 18,82" fill="none" stroke="${fill}" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" />`,
    "open-quad": `<polyline points="18,18 82,18 82,82 36,82" fill="none" stroke="${fill}" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" />`
  };

  return `
    <svg class="${className}" viewBox="0 0 100 100" aria-hidden="true">
      <g transform="rotate(${rotate} 50 50)">
        ${wrappers[item.kind] || wrappers.circle}
      </g>
      ${label}
    </svg>
  `;
}
