const fs = require("fs");
const path = require("path");

const FREESECT = 0xffffffff;
const ENDOFCHAIN = 0xfffffffe;
const FATSECT = 0xfffffffd;
const DIFSECT = 0xfffffffc;
const NOSTREAM = 0xffffffff;

function readUInt16LE(buf, offset) {
  return buf.readUInt16LE(offset);
}

function readUInt32LE(buf, offset) {
  return buf.readUInt32LE(offset);
}

function readBigUInt64LE(buf, offset) {
  return Number(buf.readBigUInt64LE(offset));
}

function sectorOffset(sectorSize, sectorId) {
  return (sectorId + 1) * sectorSize;
}

function parseHeader(buffer) {
  const signature = buffer.subarray(0, 8).toString("hex");
  if (signature !== "d0cf11e0a1b11ae1") {
    throw new Error("Not a Compound File Binary Format document.");
  }

  return {
    sectorSize: 1 << readUInt16LE(buffer, 30),
    miniSectorSize: 1 << readUInt16LE(buffer, 32),
    numDirectorySectors: readUInt32LE(buffer, 40),
    numFatSectors: readUInt32LE(buffer, 44),
    firstDirectorySector: readUInt32LE(buffer, 48),
    miniStreamCutoff: readUInt32LE(buffer, 56),
    firstMiniFatSector: readUInt32LE(buffer, 60),
    numMiniFatSectors: readUInt32LE(buffer, 64),
    firstDifatSector: readUInt32LE(buffer, 68),
    numDifatSectors: readUInt32LE(buffer, 72),
    difat: Array.from({ length: 109 }, (_, index) => readUInt32LE(buffer, 76 + index * 4))
      .filter((value) => value !== FREESECT),
  };
}

function buildDifat(buffer, header) {
  const difat = [...header.difat];
  let nextSector = header.firstDifatSector;

  for (let i = 0; i < header.numDifatSectors && nextSector !== ENDOFCHAIN; i += 1) {
    const offset = sectorOffset(header.sectorSize, nextSector);
    const entriesPerSector = header.sectorSize / 4;
    for (let entryIndex = 0; entryIndex < entriesPerSector - 1; entryIndex += 1) {
      const value = readUInt32LE(buffer, offset + entryIndex * 4);
      if (value !== FREESECT) {
        difat.push(value);
      }
    }
    nextSector = readUInt32LE(buffer, offset + (entriesPerSector - 1) * 4);
  }

  return difat;
}

function buildFat(buffer, header, difat) {
  const fat = [];
  for (const fatSector of difat.slice(0, header.numFatSectors)) {
    const offset = sectorOffset(header.sectorSize, fatSector);
    const entriesPerSector = header.sectorSize / 4;
    for (let i = 0; i < entriesPerSector; i += 1) {
      fat.push(readUInt32LE(buffer, offset + i * 4));
    }
  }
  return fat;
}

function readSectorChain(buffer, sectorSize, fat, startSector) {
  if (startSector === ENDOFCHAIN || startSector === FREESECT) {
    return Buffer.alloc(0);
  }

  const chunks = [];
  const visited = new Set();
  let sector = startSector;

  while (sector !== ENDOFCHAIN && sector !== FREESECT) {
    if (visited.has(sector)) {
      throw new Error(`Cyclic FAT chain detected at sector ${sector}.`);
    }
    visited.add(sector);

    const offset = sectorOffset(sectorSize, sector);
    chunks.push(buffer.subarray(offset, offset + sectorSize));

    const nextSector = fat[sector];
    if (nextSector === FATSECT || nextSector === DIFSECT) {
      break;
    }
    sector = nextSector;
  }

  return Buffer.concat(chunks);
}

function parseDirectory(buffer) {
  const entries = [];
  for (let offset = 0; offset + 128 <= buffer.length; offset += 128) {
    const nameLength = readUInt16LE(buffer, offset + 64);
    const rawName = buffer.subarray(offset, offset + Math.max(0, nameLength - 2));
    const name = rawName.toString("utf16le").replace(/\0+$/g, "");

    entries.push({
      id: entries.length,
      name,
      type: buffer[offset + 66],
      left: readUInt32LE(buffer, offset + 68),
      right: readUInt32LE(buffer, offset + 72),
      child: readUInt32LE(buffer, offset + 76),
      startSector: readUInt32LE(buffer, offset + 116),
      size: readBigUInt64LE(buffer, offset + 120),
    });
  }
  return entries;
}

function traverseDirectoryTree(entries) {
  const paths = new Map();
  const visitedNodes = new Set();

  function visitNode(nodeId, parentPath) {
    if (nodeId === NOSTREAM || nodeId >= entries.length) {
      return;
    }

    const entry = entries[nodeId];
    if (!entry || visitedNodes.has(`${parentPath}:${nodeId}`)) {
      return;
    }

    visitNode(entry.left, parentPath);

    const currentPath = entry.type === 5
      ? ""
      : parentPath
        ? `${parentPath}/${entry.name}`
        : entry.name;

    paths.set(currentPath, entry);
    visitedNodes.add(`${parentPath}:${nodeId}`);

    if ((entry.type === 1 || entry.type === 5) && entry.child !== NOSTREAM) {
      visitNode(entry.child, currentPath);
    }

    visitNode(entry.right, parentPath);
  }

  if (entries.length > 0) {
    visitNode(0, "");
  }

  return paths;
}

function buildMiniFat(buffer, header, fat) {
  if (header.firstMiniFatSector === ENDOFCHAIN || header.numMiniFatSectors === 0) {
    return [];
  }

  const miniFatBuffer = readSectorChain(buffer, header.sectorSize, fat, header.firstMiniFatSector)
    .subarray(0, header.numMiniFatSectors * header.sectorSize);

  const miniFat = [];
  for (let offset = 0; offset + 4 <= miniFatBuffer.length; offset += 4) {
    miniFat.push(readUInt32LE(miniFatBuffer, offset));
  }
  return miniFat;
}

function readMiniStream(rootStream, miniSectorSize, miniFat, startSector, size) {
  if (startSector === ENDOFCHAIN || startSector === FREESECT) {
    return Buffer.alloc(0);
  }

  const chunks = [];
  const visited = new Set();
  let sector = startSector;

  while (sector !== ENDOFCHAIN && sector !== FREESECT) {
    if (visited.has(sector)) {
      throw new Error(`Cyclic MiniFAT chain detected at mini sector ${sector}.`);
    }
    visited.add(sector);

    const offset = sector * miniSectorSize;
    chunks.push(rootStream.subarray(offset, offset + miniSectorSize));
    sector = miniFat[sector];
  }

  return Buffer.concat(chunks).subarray(0, size);
}

function normalizePreviewText(text) {
  return text
    .replace(/\u0000/g, "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function loadCompoundFile(filePath) {
  const buffer = fs.readFileSync(filePath);
  const header = parseHeader(buffer);
  const difat = buildDifat(buffer, header);
  const fat = buildFat(buffer, header, difat);
  const directoryBuffer = readSectorChain(buffer, header.sectorSize, fat, header.firstDirectorySector);
  const entries = parseDirectory(directoryBuffer);
  const paths = traverseDirectoryTree(entries);

  const rootEntry = entries[0];
  const rootStream = readSectorChain(buffer, header.sectorSize, fat, rootEntry.startSector)
    .subarray(0, rootEntry.size);
  const miniFat = buildMiniFat(buffer, header, fat);

  function readStream(streamPath) {
    const entry = paths.get(streamPath);
    if (!entry) {
      return null;
    }

    if (entry.size < header.miniStreamCutoff && entry.type === 2) {
      return readMiniStream(rootStream, header.miniSectorSize, miniFat, entry.startSector, entry.size);
    }

    return readSectorChain(buffer, header.sectorSize, fat, entry.startSector).subarray(0, entry.size);
  }

  return { entries, paths, readStream };
}

function main() {
  const [, , mode, fileArg, streamArg] = process.argv;
  if (!mode || !fileArg) {
    console.error("Usage: node tools/extract-hwp.js <list|preview|stream> <file> [streamPath]");
    process.exit(1);
  }

  const filePath = path.resolve(fileArg);
  const compound = loadCompoundFile(filePath);

  if (mode === "list") {
    for (const [entryPath, entry] of compound.paths.entries()) {
      const kind = entry.type === 1 ? "storage" : entry.type === 2 ? "stream" : entry.type === 5 ? "root" : "other";
      console.log(`${kind}\t${entry.size}\t${entryPath || "<root>"}`);
    }
    return;
  }

  if (mode === "preview") {
    const previewBuffer = compound.readStream("PrvText");
    if (!previewBuffer) {
      console.error("PrvText stream not found.");
      process.exit(2);
    }
    const text = normalizePreviewText(previewBuffer.toString("utf16le"));
    console.log(text);
    return;
  }

  if (mode === "stream") {
    if (!streamArg) {
      console.error("stream mode requires a stream path.");
      process.exit(1);
    }
    const streamBuffer = compound.readStream(streamArg);
    if (!streamBuffer) {
      console.error(`Stream not found: ${streamArg}`);
      process.exit(2);
    }
    process.stdout.write(streamBuffer);
    return;
  }

  console.error(`Unknown mode: ${mode}`);
  process.exit(1);
}

main();
